package com.adda.app.service;

import com.adda.app.dto.BookSeatRequest;
import com.adda.app.dto.BookSeatResponse;

public interface IBookSeatService {

	
	public BookSeatResponse bookTable(BookSeatRequest bookSeatRequest);
}
