package com.adda.app.service;

import com.adda.app.dto.OrderRequest;
import com.adda.app.dto.OrderResponse;

public interface IOrderService {

	
	public OrderResponse placeOrder(OrderRequest orderRequest);
	public OrderResponse confirmOrder(Long orderId);
}
