package com.adda.app.dto;

public class GenerateOTP {
	
//	private Integer 
}
