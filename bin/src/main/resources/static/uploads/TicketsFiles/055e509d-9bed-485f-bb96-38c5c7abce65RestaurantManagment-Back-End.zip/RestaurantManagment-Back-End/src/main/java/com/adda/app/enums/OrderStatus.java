package com.adda.app.enums;

public enum OrderStatus {
	PENDING,
    CONFIRMED,
}
