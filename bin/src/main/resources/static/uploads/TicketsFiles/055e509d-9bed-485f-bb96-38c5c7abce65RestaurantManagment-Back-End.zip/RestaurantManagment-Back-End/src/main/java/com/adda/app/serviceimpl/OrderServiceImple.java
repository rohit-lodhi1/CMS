package com.adda.app.serviceimpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adda.app.dto.OrderRequest;
import com.adda.app.dto.OrderResponse;
import com.adda.app.entity.Orders;
import com.adda.app.enums.OrderStatus;
import com.adda.app.exception.ResourceNotFoundException;
import com.adda.app.reposatory.IOrdersRepo;
import com.adda.app.service.IOrderService;
@Service
public class OrderServiceImple implements IOrderService {

	/**Some required Autowiring like moddelmapper,orderrepo,orderreplica repo*/
	@Autowired
	private ModelMapper mapper;
	@Autowired
	private IOrdersRepo orepo;
//	@Autowired
//    private INotificationService notificationService;

	@Override
	public OrderResponse placeOrder(OrderRequest orderRequest) {
		// TODO Auto-generated method stub
		Orders order = this.orderRequestToOrder(orderRequest);
		///notificationService.notifyAdminAndOwner("New order received! Order ID:"+order.getOrderId());
		return this.orderToOrderResponse( this.orepo.save(order));
		
	}
	@Override
	public OrderResponse confirmOrder(Long orderId) {
		// TODO Auto-generated method stub
		Orders order =this.orepo.findById(orderId).orElseThrow(()->new ResourceNotFoundException("Order Not Found with id: "+orderId));
		order.setOrderStatus(OrderStatus.CONFIRMED);
		Orders o=orepo.save(order);
		//notificationService.notifyUser(order.getUser().getFirstName(), "your order has been confirmed Order ID: "+order.getOrderId());
		return this.orderToOrderResponse(o);
		
	}
	

	/*convert orderrequest to order**/
	public Orders orderRequestToOrder(OrderRequest orderRequest) 
	{
		return this.mapper.map(orderRequest, Orders.class);
	}
	
	/**convert order to orderResponse*/
	public OrderResponse orderToOrderResponse(Orders orders) 
	{
		return this.mapper.map(orders, OrderResponse.class);
	}



	
}
