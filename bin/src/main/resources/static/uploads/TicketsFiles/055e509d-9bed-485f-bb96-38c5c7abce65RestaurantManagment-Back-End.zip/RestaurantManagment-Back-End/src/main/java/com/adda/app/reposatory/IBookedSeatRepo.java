package com.adda.app.reposatory;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.adda.app.entity.BookedSeat;

public interface IBookedSeatRepo extends JpaRepository<BookedSeat, Long> {

	@Query("SELECT b from BookedSeat b WHERE b.restaurant.restId=:resid AND b.table.tableId=:tid")
	BookedSeat findbookseatbyrestidandtableid(Long resid, long tid);

	@Query("SELECT b FROM BookedSeat b WHERE b.table.tableNo=:tno AND b.startTime=:sTime AND b.endTime=:eTime")
	List<BookedSeat> findOverlappingBookings(Long tno, Date sTime, Date eTime);

	 

}
