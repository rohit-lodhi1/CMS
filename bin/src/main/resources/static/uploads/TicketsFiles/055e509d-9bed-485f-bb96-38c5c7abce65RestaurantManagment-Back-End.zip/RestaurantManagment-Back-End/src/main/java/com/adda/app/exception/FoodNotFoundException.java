package com.adda.app.exception;

public class FoodNotFoundException extends RuntimeException {

	public FoodNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FoodNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
