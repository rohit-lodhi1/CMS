package com.adda.app.serviceimpl;

import java.security.Principal;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adda.app.dto.CartItemRequest;
import com.adda.app.dto.CartItemResponse;
import com.adda.app.entity.Cart;
import com.adda.app.entity.CartItem;
import com.adda.app.entity.User;
import com.adda.app.reposatory.ICartItemRepo;
import com.adda.app.reposatory.ICartRepo;
import com.adda.app.service.ICartItemService;
import com.adda.app.service.IUserService;
@Service
public class CartItemServiceImpl implements ICartItemService{
    @Autowired
	private ModelMapper modelMapper;
	@Autowired
    private ICartItemRepo cartItemRepo;
	@Autowired
	private IUserService service;
	@Autowired
	private ICartRepo cartRepo;
	@Override
	public CartItemResponse addItemToCart(CartItemRequest cartItemRequest) {
		// TODO Auto-generated method stub
		CartItem c = this.CartItemRequestToCartItem(cartItemRequest);
		CartItem existingItem =this.cartItemRepo. findCartItemByFood(c.getFood());
		if(existingItem!=null) 
		{
			 return this.updateCartItemQuantity(existingItem,existingItem.getQuantity()+cartItemRequest.getQuantity());
		}
		else
		{
		 return this.cartItemToCartItemResponse(this.cartItemRepo.save(c));
		}
	}

	public CartItemResponse updateCartItemQuantity(CartItem existingItem, int quantity) {
		// TODO Auto-generated method stub
		existingItem.setQuantity(quantity);
		System.out.println(existingItem);
		return this.cartItemToCartItemResponse(this.cartItemRepo.save(existingItem));
	}

	
	
	
	/**Convert CartItemRequest To Cart...*/
	public CartItem CartItemRequestToCartItem(CartItemRequest cartItemRequest) 
	{
		return this.modelMapper.map(cartItemRequest, CartItem.class);
	}
	/**Convert Cart To CartItemResponse...*/
	public CartItemResponse cartItemToCartItemResponse(CartItem cartItem) 
	{
		return this.modelMapper.map(cartItem, CartItemResponse.class);
	}

	@Override
	public void decreseQuantityItemFromCart(Long foodId, Principal p) {
		// TODO Auto-generated method stub
	   User u = service.getCurrentUser(p);
	   Cart c = this.cartRepo.findByUser(u);
	   CartItem item = this.cartItemRepo.getCartItemByFoodIdAndCartId(foodId,c.getId());
	   if(item!=null) 
	   {
		  int newQuantity = item.getQuantity()-1;
		  if(newQuantity>0) 
		  {
			 this.updateCartItemQuantity(item, newQuantity);
		  }else 
		  {
			  c.getCartitem().remove(item);
			  this.cartRepo.save(c);
			  this.cartItemRepo.delete(item);
		  }
	   }
	
		
	}

	@Override
	public void removeItemFromCart(Cart c, CartItem item) {
		// TODO Auto-generated method stub
		  c.getCartitem().remove(item);
		   this.cartRepo.save(c);
		  this.cartItemRepo.delete(item);
		 
	}

	
	

	

}
