package com.adda.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.entity.RegisterOTP;
import com.adda.app.service.IRegisterOTPService;
@RestController
@RequestMapping("/otp")
@CrossOrigin("*")
public class RegisterOTPController {

	@Autowired
	private IRegisterOTPService otpService;
	
	@PostMapping("/checkOTP")
	private ResponseEntity<Boolean> checkOTP(@RequestBody RegisterOTP ro)
	{
		System.out.println(ro.getEmail()+"CONTROLLER");
		Boolean checkOTP = this.otpService.checkOTP(ro.getOtp(), ro.getEmail());
		return new ResponseEntity<Boolean>(checkOTP,HttpStatus.OK);
		
	}
}
