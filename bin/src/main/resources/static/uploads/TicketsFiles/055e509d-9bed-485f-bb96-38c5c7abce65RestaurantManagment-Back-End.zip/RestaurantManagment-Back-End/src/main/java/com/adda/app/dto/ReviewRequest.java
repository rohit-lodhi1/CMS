package com.adda.app.dto;

import com.adda.app.entity.Restaurant;
import com.adda.app.entity.User;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class ReviewRequest {
	
	private Long reviewId;
	private Integer rating;

	private User user;
	private String description;


	@JsonIgnoreProperties(value= {"listofReview"})
	private Restaurant rest;
}
