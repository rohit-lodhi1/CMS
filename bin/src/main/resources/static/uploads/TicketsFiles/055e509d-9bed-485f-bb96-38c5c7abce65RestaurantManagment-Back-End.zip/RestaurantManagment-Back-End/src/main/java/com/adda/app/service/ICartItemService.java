package com.adda.app.service;

import java.security.Principal;

import com.adda.app.dto.CartItemRequest;
import com.adda.app.dto.CartItemResponse;
import com.adda.app.entity.Cart;
import com.adda.app.entity.CartItem;

public interface ICartItemService {

	public CartItemResponse addItemToCart(CartItemRequest cartItemRequest);
	public void decreseQuantityItemFromCart(Long foodId,Principal p);
	public void removeItemFromCart(Cart c,CartItem item);
	public CartItemResponse updateCartItemQuantity(CartItem existingItem, int quantity);
	
}
