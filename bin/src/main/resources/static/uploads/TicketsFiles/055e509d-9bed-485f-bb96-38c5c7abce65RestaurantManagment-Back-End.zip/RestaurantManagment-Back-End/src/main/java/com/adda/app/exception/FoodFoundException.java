package com.adda.app.exception;

public class FoodFoundException extends RuntimeException {

	public FoodFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FoodFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
