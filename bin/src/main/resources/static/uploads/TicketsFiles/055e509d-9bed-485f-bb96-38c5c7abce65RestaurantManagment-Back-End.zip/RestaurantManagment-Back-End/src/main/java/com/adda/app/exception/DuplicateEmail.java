package com.adda.app.exception;

public class DuplicateEmail extends RuntimeException {

	public DuplicateEmail() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DuplicateEmail(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
