package com.adda.app.dto;

import java.util.List;

import com.adda.app.entity.Food;
import com.adda.app.entity.Restaurant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CategoryRequest {

	private Long catId;
	private String catName;
	private String catDescription;
	private Boolean isActive;
	//@OneToMany(mappedBy = "category")
	private List<Food> listOfFood;
	//@ManyToOne
	
	private Restaurant restaurant;
}

