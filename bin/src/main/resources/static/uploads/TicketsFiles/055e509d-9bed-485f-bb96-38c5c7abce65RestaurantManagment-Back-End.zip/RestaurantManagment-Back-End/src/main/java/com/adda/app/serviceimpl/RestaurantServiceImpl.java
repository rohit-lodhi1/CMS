package com.adda.app.serviceimpl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.adda.app.dto.RestaurantRequest;
import com.adda.app.dto.RestaurantResponse;
import com.adda.app.entity.Restaurant;
import com.adda.app.exception.DataNotFoundException;
import com.adda.app.exception.RestaurantFoundException;
import com.adda.app.exception.ResturantNotFoundException;
import com.adda.app.helper.AppConstant;
import com.adda.app.paginationDto.PageRestaurantResponse;
import com.adda.app.replica.RestaurantReplica;
import com.adda.app.reposatory.IRestaurantReplicaRepo;
import com.adda.app.reposatory.IRestaurantRepo;
import com.adda.app.service.IRestaurantService;
@Service
public class RestaurantServiceImpl implements IRestaurantService{

	/** Autowire ModdelMapper...*/
	@Autowired
	private ModelMapper modelMapper;
	/** Autowire Restaurant reposatory...*/
	@Autowired
	private IRestaurantRepo repo;
	/** Autowire Restaurant Replica reposatory...*/
	@Autowired
	private IRestaurantReplicaRepo replica_repo;
	
	/** Create New Restaurant...*/
	@Override
	public RestaurantResponse saveRestaurant(RestaurantRequest restaurantrequest) {
		// TODO Auto-generated method stub
		Restaurant r = this.restaurantRequestToRestaurant(restaurantrequest);
		Restaurant r1 = this.repo.findByRestName(r.getRestName());
		if(r1!=null) 
		{
			throw new RestaurantFoundException("Restaurant Already Exist...");
		}
		r.setCreatedAt(new Date().toString());
		RestaurantReplica replica = this.restaurantToReplica(r);
		this.replica_repo.save(replica);
		return this.restaurantToRestaurantResponse(this.repo.save(r));
	}
	
	@Override
	public RestaurantResponse updateRestaurant(RestaurantRequest restaurantrequest, Long resId) {
		// TODO Auto-generated method stub
		Restaurant r = this.restaurantRequestToRestaurant(restaurantrequest);
		Optional<Restaurant> restaurant = this.repo.findById(resId);
		Restaurant r1 = this.repo.findByRestName(r.getRestName());
		if(r1!=null) 
		{
			throw new RestaurantFoundException("Restaurant Already Exist...");
		}
		else if(restaurant.isEmpty()) 
		{
			throw new ResturantNotFoundException("Restaurant Not Found "+resId);
		}
		else 
		{
			r.setRestId(resId);
			return this.restaurantToRestaurantResponse(this.repo.save(r));
			
		}
		
		
	}
	
	/** Delete restaurant */
	@Override
	public RestaurantResponse deleteRestaurant(long id) {
		// TODO Auto-generated method stub
		Optional<Restaurant> restaurant = this.repo.findById(id);
		if(restaurant.isEmpty()) 
		{
			throw new RestaurantFoundException(AppConstant.RESTAURANT_NOT_FOUND);
		}else 
		{
			Restaurant restaurant2 = restaurant.get();
			restaurant2.setIsActive(false);
			restaurant2.setRestId(id);
			this.repo.save(restaurant2);
			return restaurantToRestaurantResponse(restaurant2);
		}
		
		
	}
	
	/**find All restaurant...*/
	@Override
	public Page<RestaurantResponse> viewAllRestaurant(int pageno, int pageSize, String sortBy,RestaurantRequest request) {
		request.setListOfCategory(null);
		
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				 .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
				 .withIgnoreCase()
				 .withMatcher("restId", match->match.transform(value->value.map(id->((Long)id==0)?null:id)));
		Example<Restaurant> example = Example.of(restaurantRequestToRestaurant(request),exampleMatcher);
		Pageable pageable = PageRequest.of(pageno, pageSize,Sort.Direction.ASC,sortBy);
		Page<Restaurant> findAllRestaurant = this.repo.findAll(example,pageable);
		
		return findAllRestaurant.map(p-> restaurantToRestaurantResponse(p));
	}
	
	/**find All Active restaurant*/
	@Override
	public PageRestaurantResponse viewAllActiveRestaurant(int pageno, int pageSize, String sortBy,
			RestaurantRequest request) {
		// TODO Auto-generated method stub
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				 .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
				 .withIgnoreCase()
				 .withMatcher("restId", match->match.transform(value->value.map(id->((Long)id==0)?null:id)));
		request.setIsActive(true);
		Example<Restaurant> example = Example.of(restaurantRequestToRestaurant(request),exampleMatcher);
		Pageable pageable = PageRequest.of(pageno, pageSize,Sort.Direction.ASC,sortBy);
		Page<Restaurant> findAllRestaurant = this.repo.findAll(example,pageable);
		Page<RestaurantResponse> page = findAllRestaurant.map(r->restaurantToRestaurantResponse(r));
		List<RestaurantResponse> content = page.getContent();
		PageRestaurantResponse prr = new PageRestaurantResponse();
		if(content.isEmpty())
		{
			throw new DataNotFoundException(AppConstant.DATA_NOT_FOUND);
		}
		prr.setContents(content);
		prr.setTotalPages(findAllRestaurant.getTotalPages());
		return prr;
	}

	
	

	@Override
	public List<Restaurant> all() {
		// TODO Auto-generated method stub
		return this.repo.findAll();
	}

	
	@Override
	public RestaurantResponse undoRestaurant(Long restId) {
		// TODO Auto-generated method stub
		Optional<Restaurant> restaurant = this.repo.findById(restId);
		if(restaurant.isPresent()) 
		{
			Restaurant r = restaurant.get();
			r.setIsActive(true);
			r.setRestId(restId);
			return restaurantToRestaurantResponse(this.repo.save(r));
		}
		else 
		{
			throw new ResturantNotFoundException("restaurant not found");
		}
		
	}
	/** Restaurant To RestaurantResponse*/
	public RestaurantResponse restaurantToRestaurantResponse(Restaurant restaurant) 
	{
		return this.modelMapper.map(restaurant, RestaurantResponse.class);
	}
	
	/** RestaurantResponse To Restaurant*/
	public Restaurant restaurantRequestToRestaurant(RestaurantRequest restaurantrequest) 
	{
		return this.modelMapper.map(restaurantrequest, Restaurant.class);
	}
	public RestaurantReplica restaurantToReplica(Restaurant r) 
	{
		return this.modelMapper.map(r, RestaurantReplica.class);
	}

	@Override
	public Integer getCountingOfAllRestaurant() {
		// TODO Auto-generated method stub
		List<Restaurant> list = this.repo.findAll();
		return (Integer)list.size();
	}

	@Override
	public Integer getCountingOfActiveRestaurant() {
		// TODO Auto-generated method stub
		Integer count = 0;
		List<Restaurant> list = this.repo.findAll();
		for(Restaurant res : list)
		{
			if(res.getIsActive())
			{
				count++;
			}
		}
		return count;
	}

	@Override
	public PageRestaurantResponse viewAllInctiveRestaurant(int pageno, int pageSize, String sortBy,
			RestaurantRequest request) {
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				 .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
				 .withIgnoreCase()
				 .withMatcher("restId", match->match.transform(value->value.map(id->((Long)id==0)?null:id)));
		request.setIsActive(false);
		Example<Restaurant> example = Example.of(restaurantRequestToRestaurant(request),exampleMatcher);
		Pageable pageable = PageRequest.of(pageno, pageSize,Sort.Direction.ASC,sortBy);
		Page<Restaurant> findAllRestaurant = this.repo.findAll(example,pageable);
		Page<RestaurantResponse> page = findAllRestaurant.map(r->restaurantToRestaurantResponse(r));
		List<RestaurantResponse> content = page.getContent();
		PageRestaurantResponse prr = new PageRestaurantResponse();
		prr.setContents(content);
		prr.setTotalElements(findAllRestaurant.getTotalElements());
		return prr;
	}
	

	
	

	
	
	

}
