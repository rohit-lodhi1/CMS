package com.adda.app.enums;

public enum BookingStatus {
	 PENDING,
	    CONFIRMED,
	    WAITING,
}
