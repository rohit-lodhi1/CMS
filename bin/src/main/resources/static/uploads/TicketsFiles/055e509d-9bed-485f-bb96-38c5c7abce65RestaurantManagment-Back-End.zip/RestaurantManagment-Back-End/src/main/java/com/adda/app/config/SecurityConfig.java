package com.adda.app.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
	
	private String permitAll[]= {
			"/auth/login",
			"/auth/signup",
		    "/emailAPI/sentEmail",
		    "/otp/checkOTP",
		    "/socket/**"
	        };

   private String adminArray[] = {"/admin/restaurant/save",
		     "/admin/restaurant/delete/{id}",
		     "/admin/restaurant/undo/{restId}",
		     "/admin/restaurant/all/{pn}/{ps}/{sortBy}",
//		     "/admin/restaurant/active/{pn}/{ps}/{sortBy}",
		     "/admin/restaurant/", 
		     "/user/email/{userEmail}",
		     "/user/alluser/{pn}/{ps}/{sortBy}",
		     "/user/activeuser/{pn}/{ps}/{sortBy}",
		     "/user/allcustomer/{pn}/{ps}/{sortBy}",
		     "/user/alladmin/{pn}/{ps}/{sortBy}",
		     "/user/allowner/{pn}/{ps}/{sortBy}",
		     "/user/allboy/{pn}/{ps}/{sortBy}",
		     "/admin/category/allcategory/{pn}/{ps}/{sortBy}",
		     "/review/getAllReviewOfCustomer/{customerId}",
		     "user/getCountingOfAllCustomer"
   };
 private String adminOwnerArray[]= {
		     "/admin/rastaurant/update/{restId}",
		     "/admin/category/save",
		     "/admin/category/update/{cid}",
		     "/admin/category/delete/{cid}",
		     "/admin/food/uploadfood",
		     "/admin/food/update/{fid}",
		     "/admin/food/delete/{id}",
		     "/admin/food/undo/{id}" ,
		     "/admin/food/all/{pn}/{ps}/{sortBy}", 
		     "/owner/table/save",
		     "/owner/table/delete/{tId}",
		     "/owner/table/undo/{id}",
		     "/owner/table/update/{id}",
		     "/owner/table/all/{pn}/{ps}/{sortBy}",
             "/review/getAllReviewOfRestaurant/{pn}/{ps}/{sortBy}/{restId}"};
 private String customerArray[]= {
			"/admin/category/getActiveCatByResId/{pn}/{ps}/{sortBy}/{restId}",
			"/review/save",
			"/api/cart/save",
			"/api/cart/view-cart",
			"/api/item/add",
			"/api/item/remove",
			"/customer/bookseat/book",
			"/customer/order/place"
             };
 private String adminCustomerArray[]= {  
		   "/admin/restaurant/active/{pn}/{ps}/{sortBy}",
		   "/admin/food/active/{pn}/{ps}/{sortBy}",
           "/admin/category/active/{pn}/{ps}/{sortBy}"};
 
 private String allAuthorityArray[]= {
		 "/user/update/{userId}",
		 "/admin/category/getById/{catId}"
 };
	 
	@Autowired
	private BCryptPasswordEncoder passwoerEncoder;
	/**For User Details Services*/
	@Autowired
	private UserDetailsService userDetailsService;
	
	@Autowired
	private AuthenticationEntryPoint authenticationEntryPoint;
   @Autowired
	private SecurityFilter securityfilter;
   
   /**For Authentication.....*/
	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception 
	{
		return authConfig.getAuthenticationManager();
	}
	@Bean
	public DaoAuthenticationProvider authenticationProvider() 
	{
		DaoAuthenticationProvider provider  =  new DaoAuthenticationProvider();
		provider.setPasswordEncoder(passwoerEncoder);
		provider.setUserDetailsService(userDetailsService);
		return provider;
	}
	/**for authorization...
	 * @throws Exception */
	@Bean
	public SecurityFilterChain configurePaths(HttpSecurity http) throws Exception 
	{
		
		http
		.csrf()
		.disable()
		.authorizeRequests()
		.antMatchers(permitAll).permitAll()
	    .antMatchers(adminArray).hasAuthority("ADMIN")
		.antMatchers(adminOwnerArray).hasAnyAuthority("ADMIN","OWNER")
		.antMatchers(adminCustomerArray).hasAnyAuthority("ADMIN","CUSTOMER")
		.antMatchers(customerArray).hasAuthority("CUSTOMER")
		.antMatchers(allAuthorityArray).hasAnyAuthority("ADMIN","CUSTOMER,OWNER,BOY")
		.anyRequest().authenticated()
		.and()
		.exceptionHandling()
		.authenticationEntryPoint(authenticationEntryPoint)
		.and()
		.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
		.and()
		.addFilterBefore(securityfilter, UsernamePasswordAuthenticationFilter.class);
	
		
		return http.build();
	}
	
	
}
