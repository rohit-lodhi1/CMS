package com.adda.app.updateprofiles;

public class CustomerUpdateProfile {

}
