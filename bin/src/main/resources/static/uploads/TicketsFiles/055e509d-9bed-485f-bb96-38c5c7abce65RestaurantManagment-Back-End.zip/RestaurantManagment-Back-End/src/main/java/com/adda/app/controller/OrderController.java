package com.adda.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.dto.OrderRequest;
import com.adda.app.dto.OrderResponse;
import com.adda.app.service.IOrderService;

@RestController
@RequestMapping("/customer/order")
public class OrderController {
    @Autowired
    
	private IOrderService service;
//    @Autowired
//    private INotificationService notificationService;
    @PostMapping("/place")
    public ResponseEntity<String> placeOrder(@RequestBody OrderRequest orderRequest)
    {
    	OrderResponse o = service.placeOrder(orderRequest);
    	//notificationService.notifyAdminAndOwner("New order received! Order ID:" );
    	return new ResponseEntity<String>("order place successsfully",HttpStatus.OK);
    }
    
    
}
