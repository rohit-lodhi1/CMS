package com.adda.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.dto.CategoryRequest;
import com.adda.app.dto.CategoryResponse;
import com.adda.app.paginationDto.PageCategoryResponse;
import com.adda.app.service.ICategoryService;

@RestController
@RequestMapping("/admin/category")
@CrossOrigin("*")
public class CategoryController {
	
	/**Autowire Category Service*/
	@Autowired
	private ICategoryService service;
	
	/*Create Category BY owner and admin*/
	@PostMapping("/save")
	public ResponseEntity<CategoryResponse> createCategory(@RequestBody CategoryRequest cr)
	{
		return new ResponseEntity<CategoryResponse>(this.service.saveCategory(cr),HttpStatus.CREATED);
	}
	
	/*update Category by owner and admin*/
	@PutMapping("/update/{cid}")
	public ResponseEntity<CategoryResponse> updateCategory(@RequestBody CategoryRequest categoryResponse,@PathVariable Long cid)
	{
		//System.out.println(categoryResponse.getIsActive());
		return new ResponseEntity<CategoryResponse>(this.service.updateCategory(categoryResponse, cid),HttpStatus.OK);
	}
	
	/**delete Category by owner and admin*/
	@DeleteMapping("/delete/{cid}")
	public ResponseEntity<CategoryResponse> deleteCategory(@PathVariable Long cid)
	{
		System.out.println(cid);
		return new ResponseEntity<CategoryResponse>(this.service.deleteCategory(cid),HttpStatus.OK);	
	}
	
	/**view All Category*/
	@PostMapping("/allcategory/{pn}/{ps}/{sortBy}")
   public ResponseEntity<PageCategoryResponse> getAllCategory(@PathVariable int pn,@PathVariable int ps,@PathVariable String sortBy,@RequestBody CategoryRequest categoryRequest)
   {
	   return new ResponseEntity<PageCategoryResponse>(this.service.getAllCategory(pn, ps, sortBy, categoryRequest),HttpStatus.OK);
   }
	
   /**get All Active Category*/	
	@PostMapping("/active/{pn}/{ps}/{sortBy}")
    public ResponseEntity<PageCategoryResponse> getAllActiveCategory(@PathVariable int pn,@PathVariable int ps,@PathVariable String sortBy,@RequestBody CategoryRequest categoryRequest)
   {
    return new ResponseEntity<PageCategoryResponse>(this.service.getAllActiveCategory(pn, ps, sortBy, categoryRequest),HttpStatus.OK);
   }
	/**get All InActive Category*/	
	@PostMapping("/inactive/{pn}/{ps}/{sortBy}")
	public ResponseEntity<PageCategoryResponse> getInActiveCategory(@PathVariable int pn,@PathVariable int ps,@PathVariable String sortBy,@RequestBody CategoryRequest categoryRequest)
	{
		return new ResponseEntity<PageCategoryResponse>(this.service.getInActiveCategory(pn, ps, sortBy, categoryRequest),HttpStatus.OK);
	}
	
	/**get category by restId */
	@GetMapping("/getCatByResId/{pn}/{ps}/{sortBy}/{restId}")
	public ResponseEntity<PageCategoryResponse> getAllCategoryByRestId(@PathVariable Long restId,@PathVariable int pn,@PathVariable int ps,@PathVariable String sortBy)
	{
		return new ResponseEntity<PageCategoryResponse>(this.service.getAllCategoryOfRestaurent(pn,ps,sortBy,restId),HttpStatus.OK);
	}
	
	@GetMapping("/getActiveCatByResId/{pn}/{ps}/{sortBy}/{restId}")
	public ResponseEntity<PageCategoryResponse> getAllActiveCategoryByRestId(@PathVariable Long restId,@PathVariable int pn,@PathVariable int ps,@PathVariable String sortBy)
	{
		return new ResponseEntity<PageCategoryResponse>(this.service.getAllActiveCategoryOfRestaurent(pn,ps,sortBy,restId),HttpStatus.OK);
	}
	
	@GetMapping("getById/{catId}")
	public ResponseEntity<CategoryResponse> getCategoryById(@PathVariable Long catId)
	{
		return new ResponseEntity<CategoryResponse>(this.service.getCategoryById(catId),HttpStatus.OK);
	}
}
