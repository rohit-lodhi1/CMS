package com.adda.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.dto.UserRequest;
import com.adda.app.dto.UserResponse;
import com.adda.app.service.IUserService;

@RestController
@CrossOrigin("*")
@RequestMapping("/user")
public class UserController {
	//* Autowire user service interface.. /
	@Autowired
	private IUserService uservice;


	
	//* 2. Update User Using UserDto and User Id /
	@PutMapping("update/{userId}")
	public ResponseEntity<UserResponse> updateUser(@RequestBody UserRequest userDto,@PathVariable Long userId)
	{
		return new ResponseEntity<UserResponse>(this.uservice.updateUser(userDto, userId),HttpStatus.OK);
	}
	
	//*3. GET User Using EMAIL /
	@GetMapping("/email/{userEmail}")
	public ResponseEntity<UserResponse> getUserByEmail(@PathVariable String userEmail)
	{
		return new ResponseEntity<UserResponse>(this.uservice.findByEmail(userEmail),HttpStatus.OK);
	}
	
	//*3. GET User Using USER ID /
		@GetMapping("/userId/{userId}")
		public ResponseEntity<UserResponse> getUserByUserId(@PathVariable Long userId)
		{
			return new ResponseEntity<UserResponse>(this.uservice.findByUserId(userId),HttpStatus.OK);
		}
	
//	GET ALL ACTIVE USERS
	@GetMapping("/activeuser/{pn}/{ps}/{sortBy}")
	public ResponseEntity<List<UserResponse>> getAllActiveUser(@PathVariable int pn,@PathVariable int ps,@PathVariable("sortBy") String sortby,@RequestBody UserRequest userDto)
	{
		System.out.println(userDto.toString());
		return ResponseEntity.ok(this.uservice.findAllActiveUser(pn, ps, sortby, userDto));		
	}
	
//	GET ALL USER
	@GetMapping("/alluser/{pn}/{ps}/{sortBy}")
	public ResponseEntity<List<UserResponse>> getAllUsers(@PathVariable int pn,@PathVariable int ps,@RequestBody UserRequest userDto,@PathVariable("sortBy") String sortby)
	{
		return ResponseEntity.ok(this.uservice.findAllUser(pn, ps, sortby, userDto));
	}

//	GET ALL CUSTOMER
	@GetMapping("/allcustomer/{pn}/{ps}/{sortBy}")
	public ResponseEntity<List<UserResponse>> getAllCustomer(@PathVariable int pn,@PathVariable int ps,@RequestBody UserRequest userDto,@PathVariable("sortBy") String sortby)
	{
		return ResponseEntity.ok(this.uservice.findAllCustomer(pn, ps, sortby, userDto));
	}
	
//	GET ALL ADMIN
	@GetMapping("/alladmin/{pn}/{ps}/{sortBy}")
	public ResponseEntity<List<UserResponse>> getAllAdmin(@PathVariable int pn,@PathVariable int ps,@RequestBody UserRequest userDto,@PathVariable("sortBy") String sortby)
	{
		return ResponseEntity.ok(this.uservice.findAllAdmin(pn, ps, sortby, userDto));
	}
	
	
//	GET COUNTING OF ALL CUSTOMER
	@GetMapping("/getCountingOfAllCustomer")
	public ResponseEntity<Integer>  getCountingOfAllCustomer()
	{
		Integer coutOfAllCustomer = this.uservice.getCoutOfAllCustomer();
		return new ResponseEntity<Integer>(coutOfAllCustomer,HttpStatus.OK);
	}
	
//	GET COUNTING OF ACTIVE CUSTOMER
	@GetMapping("/getCountingOfInActiveCustomer")
	public ResponseEntity<Integer>  getCountingOfInActiveCustomer()
	{
		Integer coutOfInActiveCustomer = this.uservice.getCoutOfInactiveCustomer();
		return new ResponseEntity<Integer>(coutOfInActiveCustomer,HttpStatus.OK);
	}
	
	
//	GET COUNTING OF INACTIVE CUSTOMER
	@GetMapping("/getCountingOfActiveCustomer")
	public ResponseEntity<Integer>  getCountingOfActiveCustomer()
	{
		Integer coutOfActiveCustomer = this.uservice.getCoutOfActiveCustomer();
		return new ResponseEntity<Integer>(coutOfActiveCustomer,HttpStatus.OK);
	}
	
//	GET COUNTING OF ALL USERS
	@GetMapping("/getCountingOfAllUsers")
	public ResponseEntity<Integer> getCountingOfAllUsers()
	{
		Integer coutOfAllUsers = this.uservice.getCoutOfAllUsers();
		return new ResponseEntity<Integer>(coutOfAllUsers,HttpStatus.OK);
	}
	
//	GET ALL RESTAURANT OWNER
	@GetMapping("/allowner/{pn}/{ps}/{sortBy}")
	public ResponseEntity<List<UserResponse>> getAllRestaurantOwner(@PathVariable int pn,@PathVariable int ps,@RequestBody UserRequest userDto,@PathVariable("sortBy") String sortby)
	{
		return ResponseEntity.ok(this.uservice.findAllRestaurantOwner(pn, ps, sortby, userDto));
	}
	
//	GET ALL DELIVERY BOY
	@GetMapping("/allboy/{pn}/{ps}/{sortBy}")
	public ResponseEntity<List<UserResponse>> getAllDeliveryBoy(@PathVariable int pn,@PathVariable int ps,@RequestBody UserRequest userDto,@PathVariable("sortBy") String sortby)
	{
		return ResponseEntity.ok(this.uservice.findAllDeliveryBoy(pn, ps, sortby, userDto));
	}
	

	
//	GET USER BY ID
	@GetMapping("/{userId}")
	public ResponseEntity<UserResponse> getUserById(@PathVariable Long userId)
	{
		return ResponseEntity.ok(this.uservice.getById(userId));
	}
	
//	SOFT DELETE A USER BY USER ID
	@DeleteMapping("/softDelete/{userId}")
	public ResponseEntity<UserResponse> softDeleteUserByUserId(@PathVariable Long userId)
	{
		return ResponseEntity.ok(this.uservice.softDelete(userId));
	}
	
//	UNDO DELETED USER BY ID
	@GetMapping("/undo/{userId}")
	public ResponseEntity<UserResponse> undoDeletedUser(@PathVariable Long userId)
	{
		return ResponseEntity.ok(this.uservice.undoUser(userId));
	}
	
}
