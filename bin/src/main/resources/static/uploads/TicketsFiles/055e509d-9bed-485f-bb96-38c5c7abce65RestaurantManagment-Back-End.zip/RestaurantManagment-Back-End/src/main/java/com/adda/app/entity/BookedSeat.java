package com.adda.app.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.adda.app.enums.BookingStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class BookedSeat {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long bookedSeatId;
	private Date startTime;
	private Date endTime;
	@Enumerated(EnumType.STRING)
	private BookingStatus  status;
	@ManyToOne
	@JoinColumn(name = "table_id")
	private TableSeat table;
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
	@ManyToOne
	@JoinColumn(name="rest_id")
	private Restaurant restaurant;
	
}
