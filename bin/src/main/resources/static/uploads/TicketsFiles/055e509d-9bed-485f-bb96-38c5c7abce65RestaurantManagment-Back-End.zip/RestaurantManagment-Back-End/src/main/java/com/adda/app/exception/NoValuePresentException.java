package com.adda.app.exception;

public class NoValuePresentException extends RuntimeException{

	public NoValuePresentException() {
		super("Category  Alredy Exist...");
		// TODO Auto-generated constructor stub
	}

	public NoValuePresentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
