package com.adda.app.service;

import java.util.List;

import com.adda.app.dto.TableRequest;
import com.adda.app.dto.TableResponse;

public interface ITableService {

	public TableResponse saveTable(TableRequest tableRequest);
	public TableResponse updateTable(TableRequest tableRequest,Long tId);
	public TableResponse deleteTable(Long id);
	public List<TableResponse> viewAllTable(int pn,int ps,String sortby,TableRequest tableRequest);
	public TableResponse undoTable(Long tId);
}
