package com.adda.app.exception;

public class CategoryFoundException extends RuntimeException{

	public CategoryFoundException() {
		super("Category  Alredy Exist...");
		// TODO Auto-generated constructor stub
	}

	public CategoryFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
