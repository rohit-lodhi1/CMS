package com.adda.app.dto;

import com.adda.app.entity.Category;
import com.adda.app.entity.Restaurant;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class FoodResponse {

	private Long foodId;
	private String foodName;
	private Long foodPrice;
	private String foodCreatedAt;
	
	private String imageName;
	private String type;
	private Boolean isAvailable;
	private String foodCategoryName;
	//@ManyToOne
//	@JoinColumn(name = "restId")
    @JsonIgnore
	private Restaurant restaurant;
//	@ManyToOne
//	@JoinColumn(name = "catId")
	@JsonIgnore
	private Category category;
	public FoodResponse(String foodName, Long foodPrice, byte[] foodimage, boolean isAvailable, Restaurant restaurant,
			Category category) {
		super();
		this.foodName = foodName;
		this.foodPrice = foodPrice;
		this.isAvailable = isAvailable;
		this.restaurant = restaurant;
		this.category = category;
	}	
}
