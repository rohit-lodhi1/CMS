package com.adda.app.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class RestaurantResponse {

	private Long restId;
	private String restName;
	private String restCloseTime;
	private String restOpentime;
	private boolean restTableStatus;
	private boolean restPickupStatus;
	private boolean deliveryStatus;
	private boolean isActive;
	private boolean waiterStatus;
	private boolean currentStatus;
	private String Address;
	private String restDescription;
	private String createdAt;
	private String lat;
	private String longg;

}
