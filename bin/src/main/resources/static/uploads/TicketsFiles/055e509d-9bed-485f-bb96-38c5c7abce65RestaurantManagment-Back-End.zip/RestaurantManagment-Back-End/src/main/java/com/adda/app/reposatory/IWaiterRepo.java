package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adda.app.entity.Waiter;

public interface IWaiterRepo extends JpaRepository<Waiter, Long>{

}
