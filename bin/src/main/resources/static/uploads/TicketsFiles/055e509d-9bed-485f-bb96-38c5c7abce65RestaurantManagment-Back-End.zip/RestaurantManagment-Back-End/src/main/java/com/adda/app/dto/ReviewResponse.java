package com.adda.app.dto;

import com.adda.app.entity.Restaurant;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor

public class ReviewResponse {
	private Long reviewId;
	private Integer rating;
	private UserResponse user;
	private String description;
	@JsonIgnore
	private Restaurant rest;
}
