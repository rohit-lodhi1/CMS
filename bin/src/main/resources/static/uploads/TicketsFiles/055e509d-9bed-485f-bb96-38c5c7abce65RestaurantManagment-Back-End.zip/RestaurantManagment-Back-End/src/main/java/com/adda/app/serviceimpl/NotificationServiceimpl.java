//package com.adda.app.serviceimpl;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.messaging.simp.SimpMessagingTemplate;
//import org.springframework.stereotype.Service;
//
//import com.adda.app.service.INotificationService;
//@Service
//public class NotificationServiceimpl implements INotificationService {
//  @Autowired
//	private SimpMessagingTemplate messagingTemplate;
//  int c=0;
//	@Override
//	public void notifyAdminAndOwner(String message) {
//		
//		// TODO Auto-generated method stub
//		
//		 messagingTemplate.convertAndSend("/topic/admin-notifications", message);
//		
//	        messagingTemplate.convertAndSend("/topic/owner-notifications", message);
//
//	}
//
//	@Override
//	public void notifyUser(String username, String message) {
//		// TODO Auto-generated method stub
//		messagingTemplate.convertAndSendToUser(username, "/queue/user-notifications", message);
//
//	}
//
//}


