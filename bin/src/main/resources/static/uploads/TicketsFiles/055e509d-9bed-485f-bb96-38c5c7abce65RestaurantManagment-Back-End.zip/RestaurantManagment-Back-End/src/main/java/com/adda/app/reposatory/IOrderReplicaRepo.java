package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adda.app.replica.orderReplica;

public interface IOrderReplicaRepo extends JpaRepository<orderReplica,Long>{

}
