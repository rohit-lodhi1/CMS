package com.adda.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.dto.RestaurantRequest;
import com.adda.app.dto.RestaurantResponse;
import com.adda.app.entity.Restaurant;
import com.adda.app.paginationDto.PageRestaurantResponse;
import com.adda.app.service.IRestaurantService;

@RestController
@RequestMapping("/admin/restaurant")
@CrossOrigin("*")
public class RestaurantController {

	/**Autowire restaurant service*/
	@Autowired
	private IRestaurantService service;
	
	/** ADD REATAURANT BY ADMIN*/
	@PostMapping("/save")
	public ResponseEntity<RestaurantResponse> createRestaurant(@RequestBody RestaurantRequest rs )
	{
		return new ResponseEntity<RestaurantResponse>(this.service.saveRestaurant(rs),HttpStatus.CREATED);
	}
	
	/** UPDATE RESTAURANT BY ADMIN AND OWNER*/
	@PutMapping("/update/{restId}")
	public ResponseEntity<RestaurantResponse> updateRestaurant(@RequestBody RestaurantRequest rs,@PathVariable Long restId)
	{
		return new ResponseEntity<RestaurantResponse>(this.service.updateRestaurant(rs, restId),HttpStatus.OK);
	}
	
	/** DELETE RESTAURANT BY ADMIN*/
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<RestaurantResponse> softDeleteRestaurantByRestId(@PathVariable long id)
	{
		return new ResponseEntity<RestaurantResponse>(this.service.deleteRestaurant(id),HttpStatus.OK);
	}
	
	/** VIEW ALL RESTAURANT*/
	@PostMapping("/all/{pn}/{ps}/{sortBy}")
	public ResponseEntity<Page<RestaurantResponse>> getAllRestaurant(@PathVariable("pn") int pageNo,@PathVariable("ps") int pageSize,@PathVariable String sortBy,@RequestBody RestaurantRequest request)
	{
		return new ResponseEntity<Page<RestaurantResponse>>(this.service.viewAllRestaurant(pageNo, pageSize, sortBy, request),HttpStatus.OK);
	}
	
	/** VIEW ALL ACTIVE RESTAURANT...*/
	@PostMapping("/active/{pn}/{ps}/{sortBy}")
	public ResponseEntity<PageRestaurantResponse> getAllActiveRestaurant(@PathVariable("pn") int pn,@PathVariable("ps") int pageSize,@PathVariable String sortBy,@RequestBody RestaurantRequest request)
	{
		return new ResponseEntity<PageRestaurantResponse>(service.viewAllActiveRestaurant(pn, pageSize, sortBy, request),HttpStatus.OK);
	}
	
	/** VIEW ALL InACTIVE RESTAURANT...*/
	@PostMapping("/inactive/{pn}/{ps}/{sortBy}")
	public ResponseEntity<PageRestaurantResponse> getAllInactiveRestaurant(@PathVariable("pn") int pn,@PathVariable("ps") int pageSize,@PathVariable String sortBy,@RequestBody RestaurantRequest request)
	{
		return new ResponseEntity<PageRestaurantResponse>(service.viewAllInctiveRestaurant(pn, pageSize, sortBy, request),HttpStatus.OK);
	}
	
  @GetMapping("/")
	public ResponseEntity<List<Restaurant>> getAll()
	{
		return new ResponseEntity<List<Restaurant>>(this.service.all(),HttpStatus.OK);
	}
	
  @GetMapping("/undo/{restId}")
	public ResponseEntity<RestaurantResponse> undoDeletedRestaurant(@PathVariable Long restId)
	{
		return ResponseEntity.ok(this.service.undoRestaurant(restId));
	}
  
  	@GetMapping("/getCountingOfAllRestaurant")
  	public ResponseEntity<Integer> getCountingOfAllRestaurant()
  	{
  		Integer countingOfAllRestaurant = this.service.getCountingOfAllRestaurant();
  		return new ResponseEntity<Integer>(countingOfAllRestaurant,HttpStatus.OK);
  	}
	
  	@GetMapping("/getCountingOfActiveRestaurant")
  	public ResponseEntity<Integer> getCountingOfActiveRestaurant()
  	{
  		Integer countingOfActiveRestaurant = this.service.getCountingOfActiveRestaurant();
  		return new ResponseEntity<Integer>(countingOfActiveRestaurant,HttpStatus.OK);
  	}
	
}
