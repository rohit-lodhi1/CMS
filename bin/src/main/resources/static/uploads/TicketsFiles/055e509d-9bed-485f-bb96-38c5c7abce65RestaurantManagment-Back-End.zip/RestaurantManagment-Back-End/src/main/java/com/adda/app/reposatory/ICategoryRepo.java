package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.adda.app.entity.Category;

public interface ICategoryRepo extends JpaRepository<Category, Long>{

	
	Category findBycatName(String name);
	
	public Category findCatnameByCatId(Long id);

	@Query("SELECT c FROM Category c WHERE c.catName=:cName AND c.restaurant.restId=:rId")
	Category findBycatNameAndRestId(String cName, Long rId);
	
}
