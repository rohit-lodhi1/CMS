package com.adda.app.exception;

public class DataNotFoundException extends RuntimeException{

	public DataNotFoundException() {
		super("Category  Alredy Exist...");
		// TODO Auto-generated constructor stub
	}

	public DataNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
