package com.adda.app.replica;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class RestaurantReplica {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long restReplicaId;
	private String restName;
	private String restCelosetime;
	private String restOpentime;
	private boolean restTableStatus;
	private boolean restPickupStatus;
	private boolean deliveryStatus;
	private boolean isActive;
	private boolean waiterStatus;
	private boolean currentStatus;
	private String Address;
	private String restDescription;
	private String createdAt;
	private String lat;
	private String longg;

}
