package com.adda.app.dto;

import com.adda.app.entity.Cart;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CartItemResponse {
	private Long id;
	@JsonIgnore
	private Cart cart;
	
	private FoodRequest food;
	private int quantity;
	private Long price;
}
