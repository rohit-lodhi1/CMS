package com.adda.app.service;

public interface INotificationService {

	public void notifyAdminAndOwner(String msg);
	public void notifyUser(String username,String message);
}
