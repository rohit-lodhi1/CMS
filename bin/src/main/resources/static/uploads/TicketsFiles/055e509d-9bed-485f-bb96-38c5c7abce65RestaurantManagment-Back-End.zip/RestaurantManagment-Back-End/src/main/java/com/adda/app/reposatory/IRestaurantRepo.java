package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adda.app.entity.Restaurant;

public interface IRestaurantRepo extends JpaRepository<Restaurant, Long> {

	public Restaurant findByRestName(String restName);
	
//	public Restaurant findByIsActive(Boolean b );
	
}
