package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adda.app.entity.Review;

public interface IReviewRepo extends JpaRepository<Review, Long> {

}
