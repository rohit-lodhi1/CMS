package com.adda.app.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.StringMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.adda.app.dto.CategoryRequest;
import com.adda.app.dto.CategoryResponse;
import com.adda.app.entity.Category;
import com.adda.app.entity.Restaurant;
import com.adda.app.exception.CategoryFoundException;
import com.adda.app.exception.CategoryNotFoundException;
import com.adda.app.exception.ResturantNotFoundException;
import com.adda.app.helper.AppConstant;
import com.adda.app.paginationDto.PageCategoryResponse;
import com.adda.app.reposatory.ICategoryRepo;
import com.adda.app.reposatory.IRestaurantRepo;
import com.adda.app.service.ICategoryService;
@Service
public class CategoryServiceimpl implements ICategoryService {
	/**Autowire Category reposatory...*/
	@Autowired
	private ICategoryRepo crepo;
	/**Autowire Restaurant reposatory...*/
	@Autowired
	private IRestaurantRepo restRepo;
	/**Autowire modelmapper ...*/
	@Autowired
	private ModelMapper moddelmapper;
	
	/*create  Category*/
	@Override
	public CategoryResponse saveCategory(CategoryRequest category) {
		// TODO Auto-generated method stub
		Category c = reqToCat(category);
		Category c1 = crepo.findBycatName(c.getCatName());
		if(c1!=null) 
		{
		   throw new  CategoryFoundException("Category Already Exist......");
		}
		
		return catToRes(crepo.save(c));
	}
	
	/*update Category*/
	@Override
	public CategoryResponse updateCategory(CategoryRequest category, Long catId) {
		// TODO Auto-generated method stub
		Category c = this.reqToCat(category);
		Category c1 = crepo.findBycatNameAndRestId(c.getCatName(),c.getRestaurant().getRestId());
		Optional<Category> cat = this.crepo.findById(catId);
		if(c1!=null && c1.getCatId() != catId) 
		{
		   throw new  CategoryFoundException("Category Already Exist......");
		}
		else if(cat.isEmpty() && c1.getCatId() != catId) 
		{
			throw new CategoryNotFoundException("Category Not Found in this id..."+catId);
		}
		
		else {
			c.setCatId(catId);
			return this.catToRes(this.crepo.save(c));
		}
		
		
	}
	
	
	/**delete category*/
	@Override
	public CategoryResponse deleteCategory(Long id) {
		// TODO Auto-generated method stub
		Optional<Category> category = this.crepo.findById(id);
		if(category.isEmpty()) 
		{
			throw new CategoryNotFoundException(AppConstant.CATEGORY_NOT_FOUND);
		}
		else 
		{
		  Category c = category.get();
		  c.setIsActive(false);
		  c.setCatId(id);
		  this.crepo.save(c);
		  return this.catToRes(c);
		}
		
	}
	
	
	

	

	@Override
	public PageCategoryResponse getAllActiveCategory(int pn, int ps, String sortBy, CategoryRequest categoryRequest) {
		// TODO Auto-generated method stub
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(StringMatcher.EXACT.CONTAINING)
				.withIgnoreCase()
				.withMatcher("cat_id", match->match.transform(value->value.map(id->((Long)id==0)?null:id)));
		categoryRequest.setIsActive(true);
		Example<Category> example = Example.of(reqToCat(categoryRequest),exampleMatcher);
		Pageable pageable = PageRequest.of(pn, ps,Sort.Direction.ASC,sortBy);
		Page<Category> findAllCategory = this.crepo.findAll(example,pageable);
		List<CategoryResponse> collect = findAllCategory.getContent().stream().map(c->catToRes(c)).collect(Collectors.toList());
		PageCategoryResponse pcr = new PageCategoryResponse();
		collect.sort((o1, o2)
                -> o1.getCatId().compareTo(
                    o2.getCatId()));
		pcr.setContents(collect);
		pcr.setTotalElements(findAllCategory.getTotalElements());
		return pcr;
	}

	@Override
	public PageCategoryResponse getAllCategory(int pn, int ps, String sortBy, CategoryRequest categoryRequest) {
		// TODO Auto-generated method stub
		
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(StringMatcher.EXACT.CONTAINING)
				.withIgnoreCase()
				.withMatcher("cat_id", match->match.transform(value->value.map(id->((Long)id==0)?null:id)));
		Example<Category> example = Example.of(reqToCat(categoryRequest),exampleMatcher);
		Pageable pageable = PageRequest.of(pn, ps,Sort.Direction.ASC,sortBy);
		Page<Category> findAllCategory = this.crepo.findAll(example,pageable);
		List<CategoryResponse> collect = findAllCategory.getContent().stream().map(c->catToRes(c)).collect(Collectors.toList());
		PageCategoryResponse pcr = new PageCategoryResponse();
		collect.sort((o1, o2)
                 -> o1.getCatId().compareTo(
                     o2.getCatId()));
		pcr.setContents(collect);
//		pcr.setTotalElements(findAllCategory.getTotalElements());
		pcr.setTotalElements(Long.valueOf(collect.size()));
		return pcr;
	}

	@Override
	public PageCategoryResponse getAllCategoryOfRestaurent(int pn, int ps, String sortBy,Long resId) {
		// TODO Auto-generated method stub
		Optional<Restaurant> findById = this.restRepo.findById(resId);
		if(findById.isPresent()) 
		{
			Restaurant restaurant = findById.get();
			List<Category> listOfCategory = restaurant.getListOfCategory();
			List<CategoryResponse> collect = listOfCategory.stream().map(r->catToRes(r)).collect(Collectors.toList());
			Pageable pageRequest = PageRequest.of(pn, ps);
			int start = (int) pageRequest.getOffset();
		    int end = Math.min((start + pageRequest.getPageSize()), collect.size());
		    List<CategoryResponse> pageContent = collect.subList(start, end);
		    PageImpl<CategoryResponse> pageImpl = new PageImpl<>(pageContent, pageRequest, collect.size());
		    PageCategoryResponse pcr = new PageCategoryResponse();
		    pcr.setContents(pageContent);
		    pcr.setTotalElements(pageImpl.getTotalElements());
			return pcr;
		}
		
		throw new ResturantNotFoundException(AppConstant.RESTAURANT_NOT_FOUND);
		
	}
	
	

	@Override
	public PageCategoryResponse getAllActiveCategoryOfRestaurent(int pn, int ps, String sortBy,Long resId) {
		// TODO Auto-generated method stub
		Optional<Restaurant> findById = this.restRepo.findById(resId);
		System.out.println(findById.get().getRestId()+"...................");
		if(findById.isPresent())
		{
			Restaurant restaurant = findById.get();
			List<Category> listOfCategory = restaurant.getListOfCategory();
			List<CategoryResponse> response = new ArrayList<>();
			for(Category c : listOfCategory)
			{
				if(c.getIsActive())
				{
					response.add(this.catToRes(c));
				}
			}
			Pageable pageRequest = PageRequest.of(pn, ps);
			int start = (int) pageRequest.getOffset();
		    int end = Math.min((start + pageRequest.getPageSize()), response.size());
		    List<CategoryResponse> pageContent = response.subList(start, end);
		    PageImpl<CategoryResponse> pageImpl = new PageImpl<>(pageContent, pageRequest, response.size());
		    PageCategoryResponse pcr = new PageCategoryResponse();
		    pcr.setContents(pageContent);
		    System.out.println(pageContent.size()   +"    SIZE OF PAGE CONTENT");
		    pcr.setTotalElements(Long.valueOf(pageContent.size()));
			
			return pcr;
		}
		throw new ResturantNotFoundException(AppConstant.RESTAURANT_NOT_FOUND);
	}
	
	/** Category to CategoryResponse....*/
	public CategoryResponse catToRes(Category c) 
	{
		CategoryResponse categoryResponse = this.moddelmapper.map(c, CategoryResponse.class);
		return categoryResponse;
	}
	
	/** CategoryRequest to Category....*/
	public Category reqToCat(CategoryRequest cr) 
	{
		Category c = this.moddelmapper.map(cr, Category.class);
		return c;
	}

	@Override
	public CategoryResponse getCategoryById(Long catId) {
		// TODO Auto-generated method stub
		Optional<Category> optional = this.crepo.findById(catId);
		if(optional.isPresent())
		{
			return this.catToRes(optional.get());
		}
		throw new CategoryNotFoundException(AppConstant.CATEGORY_NOT_FOUND);
	}

	@Override
	public PageCategoryResponse getInActiveCategory(int pn, int ps, String sortBy, CategoryRequest categoryRequest) {
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(StringMatcher.EXACT.CONTAINING)
				.withIgnoreCase()
				.withMatcher("cat_id", match->match.transform(value->value.map(id->((Long)id==0)?null:id)));
	   categoryRequest.setIsActive(false);
		Example<Category> example = Example.of(reqToCat(categoryRequest),exampleMatcher);
		Pageable pageable = PageRequest.of(pn, ps,Sort.Direction.ASC,sortBy);
		Page<Category> findAllCategory = this.crepo.findAll(example,pageable);
		List<CategoryResponse> collect = findAllCategory.getContent().stream().map(c->catToRes(c)).collect(Collectors.toList());
		PageCategoryResponse pcr = new PageCategoryResponse();
		collect.sort((o1, o2)
                -> o1.getCatId().compareTo(
                    o2.getCatId()));
		pcr.setContents(collect);
		pcr.setTotalElements(findAllCategory.getTotalElements());
		return pcr;
	}
	}

	

	

	
	


