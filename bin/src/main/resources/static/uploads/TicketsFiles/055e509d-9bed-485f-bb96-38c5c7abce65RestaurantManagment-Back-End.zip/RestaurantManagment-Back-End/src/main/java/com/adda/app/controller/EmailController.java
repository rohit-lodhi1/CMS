package com.adda.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.dto.EmailRequest;
import com.adda.app.service.IEmailService;
@CrossOrigin("*")
@RestController
@RequestMapping("/emailAPI")
public class EmailController {
	
	@Autowired
	private IEmailService emailService;
	
//	TO SENT EMAIL
	@PostMapping("/sentEmail")
	public ResponseEntity<?> sentEmail(@RequestBody EmailRequest emailRequest)
	{
			
		 Boolean entity = this.emailService.sendEmail(emailRequest
					.getSubject(), emailRequest.getMessage(), emailRequest.getSendTo());
		 if(entity)
		 {
			 return ResponseEntity.ok("Email Sent Sucessfully....");
		 }
		 else
		 {
			 return ResponseEntity.ok("Something went wrong....");
		 }
	}
	
}
