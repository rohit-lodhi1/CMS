package com.adda.app.exception;

public class ReviewNotFoundException extends RuntimeException{

	public ReviewNotFoundException() {
		super("Category  Alredy Exist...");
		// TODO Auto-generated constructor stub
	}

	public ReviewNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
