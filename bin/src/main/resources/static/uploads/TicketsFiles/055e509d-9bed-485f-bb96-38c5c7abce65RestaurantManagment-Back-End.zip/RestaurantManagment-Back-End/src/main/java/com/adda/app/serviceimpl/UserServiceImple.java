package com.adda.app.serviceimpl;

import java.security.Principal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.adda.app.dto.UserRequest;
import com.adda.app.dto.UserResponse;
import com.adda.app.entity.Role;
import com.adda.app.entity.User;
import com.adda.app.entity.UserRole;
import com.adda.app.exception.UserFoundException;
import com.adda.app.exception.UserNotFoundException;
import com.adda.app.helper.AppConstant;
import com.adda.app.reposatory.IUserRepo;
import com.adda.app.service.IUserService;

//* User Service implementation... /

@Service
public class UserServiceImple implements IUserService ,UserDetailsService{

//	Autowired With User Repository
	@Autowired
	private IUserRepo userRepo;

//	AutoWired with Model Mapper Bean
	@Autowired
	private ModelMapper modelmapper;

// Autowire Password encoder
	@Autowired
	private BCryptPasswordEncoder pass;
	
	/**
	 * Create User
	 * 
	 * @throws UserFoundException
	 */
	@Override
	public UserResponse createUser(UserRequest user) throws UserFoundException {
		// TODO Auto-generated method stub
		User local = this.userRepo.findByEmail(user.getEmail());
		if (local != null) {
			System.out.println("user is already there !!");
			throw new UserFoundException(AppConstant.EMAIL_IN_USE);

		}

		local = dtoToUser(user);

		Set<UserRole> roles = new HashSet<>();
		Role role = new Role();
		if (user.getTempRole().equalsIgnoreCase("boy")) {

			System.out.println("this is create user");
			role.setRoleId(10L);
			role.setRoleName("BOY");

			UserRole userRole = new UserRole();
			userRole.setUser(local);
			userRole.setRole(role);
			roles.add(userRole);
			local.setIsActive(false);

		}

		else if (user.getTempRole().equalsIgnoreCase("owner")) {
			
			role.setRoleId(20L);
			role.setRoleName("OWNER");

			UserRole userRole = new UserRole();
			userRole.setUser(local);
			userRole.setRole(role);
			roles.add(userRole);
			local.setIsActive(false);

		}

		else {
			
			role.setRoleId(30L);
			role.setRoleName("CUSTOMER");

			UserRole userRole = new UserRole();
			userRole.setUser(local);
			userRole.setRole(role);
			roles.add(userRole);
			local.setIsActive(true);

		}
		local.setJoinAt(LocalDate.now());
		local.setUserRole(roles);
		local.setPassword(pass.encode(local.getPassword()));
		local = this.userRepo.save(local);

		return userToDto(local);
	}

//	UPDATE USER BY USER ID
	@Override
	public UserResponse updateUser(UserRequest user, Long userId) throws UserFoundException {
		// TODO Auto-generated method stu
		User u = dtoToUser(user);
		Optional<User> findById = this.userRepo.findById(userId);
		
		if (findById.isPresent() && findById.get().getEmail().equals(u.getEmail())) {
			u.setUserId(userId);
			
			u.setPassword(pass.encode(u.getPassword()));
			u = this.userRepo.save(u);
		} else {
			throw new UserFoundException(AppConstant.UPDATE_USER);
		}

		return userToDto(u);
	}
	
//	FIND USER BY USER ID
	@Override
	public UserResponse findByUserId(Long userId) {
		// TODO Auto-generated method stub
		User user = this.userRepo.findById(userId).get();
		return userToDto(user);
	}
	
//	FIND USER BY USER EMAIL
	@Override
	public UserResponse findByEmail(String email) {
		// TODO Auto-generated method stub
		User user = this.userRepo.findByEmail(email);
		return userToDto(user);
	}

//	GET ALL USER WITH SORTING AND PAGINATION
	@Override
	public List<UserResponse> findAllUser(int pn, int pageSize, String sortBy, UserRequest userDto) {
		ExampleMatcher examplematcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
				.withIgnoreCase()
				.withMatcher("user_id",match -> match.transform(value -> value.map(id -> ((Long) id == 0) ? null : id)));
		Example<User> example = Example.of(dtoToUser(userDto), examplematcher);
		Pageable pagebale = PageRequest.of(pn, pageSize, Sort.Direction.ASC, sortBy);
		Page<User> findAll = this.userRepo.findAll(example, pagebale);
		List<User> content = findAll.getContent();
		List<UserResponse> dtoList = new ArrayList<>();
		for (User u : content) {
			dtoList.add(userToDto(u));
		}
		
		return dtoList;
	}

//	GET ALL ACTIVE USER WITH SORTING AND PAGINATION
	@Override
	public List<UserResponse> findAllActiveUser(int pn, int pageSize, String sortBy, UserRequest userDto) {
		ExampleMatcher examplematcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
				.withIgnoreCase()
				.withMatcher("user_id",match -> match.transform(value -> value.map(id -> ((Long) id == 0) ? null : id)));
		Example<User> example = Example.of(dtoToUser(userDto), examplematcher);
		Pageable pagebale = PageRequest.of(pn, pageSize, Sort.Direction.ASC, sortBy);
		Page<User> findAll = this.userRepo.findAll(example, pagebale);
    
		
		return    findAll.getContent().stream().map(u -> userToDto(u)).collect(Collectors.toList());
	}

//	GET ALL CUSTOMER WITH SORTING AND PAGINATION
	@Override
	public List<UserResponse> findAllCustomer(int pn, int pageSize, String sortBy, UserRequest userDto) {
		ExampleMatcher examplematcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
				.withIgnoreCase()
				.withMatcher("user_id",match -> match.transform(value -> value.map(id -> ((Integer) id == 0) ? null : id)));
		Example<User> example = Example.of(dtoToUser(userDto), examplematcher);
		Pageable pagebale = PageRequest.of(pn, pageSize, Sort.Direction.ASC, sortBy);
		Page<User> findAll = this.userRepo.findAll(example, pagebale);
		List<User> content = findAll.getContent();
		List<UserResponse> dtoList = new ArrayList<>();
		for (User u : content) {
			for(UserRole ur : u.getUserRole())
			{
				if(ur.getRole().getRoleName().equals("CUSTOMER"))
					dtoList.add(userToDto(u));
			}
		}
		return dtoList;
	}

//	GET ALL ADMIN WITH SORTING AND PAGINATION
	@Override
	public List<UserResponse> findAllAdmin(int pn, int pageSize, String sortBy, UserRequest userDto) {
		ExampleMatcher examplematcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
				.withIgnoreCase()
				.withMatcher("user_id",match -> match.transform(value -> value.map(id -> ((Integer) id == 0) ? null : id)));
		Example<User> example = Example.of(dtoToUser(userDto), examplematcher);
		Pageable pagebale = PageRequest.of(pn, pageSize, Sort.Direction.ASC, sortBy);
		Page<User> findAll = this.userRepo.findAll(example, pagebale);
		List<User> content = findAll.getContent();
		List<UserResponse> dtoList = new ArrayList<>();
		for (User u : content) {
			for(UserRole ur : u.getUserRole())
			{
				if(ur.getRole().getRoleName().equals("ADMIN"))
					dtoList.add(userToDto(u));
			}
		}
		return dtoList;
	}

	@Override
	public List<UserResponse> findAllDeliveryBoy(int pn, int pageSize, String sortBy, UserRequest userDto) {
		ExampleMatcher examplematcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
				.withIgnoreCase()
				.withMatcher("user_id",match -> match.transform(value -> value.map(id -> ((Integer) id == 0) ? null : id)));
		Example<User> example = Example.of(dtoToUser(userDto), examplematcher);
		Pageable pagebale = PageRequest.of(pn, pageSize, Sort.Direction.ASC, sortBy);
		Page<User> findAll = this.userRepo.findAll(example, pagebale);
		List<User> content = findAll.getContent();
		List<UserResponse> dtoList = new ArrayList<>();
		for (User u : content) {
			for(UserRole ur : u.getUserRole())
			{
				if(ur.getRole().getRoleName().equals("BOY"))
					dtoList.add(userToDto(u));
			}
		}
		return dtoList;
	}

	
//	GET ALL RESTAURANT OWNER WITH SORTING AND PAGINATION
	@Override
	public List<UserResponse> findAllRestaurantOwner(int pn, int pageSize, String sortBy, UserRequest userDto) {
		ExampleMatcher examplematcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
				.withIgnoreCase()
				.withMatcher("user_id",match -> match.transform(value -> value.map(id -> ((Integer) id == 0) ? null : id)));
		Example<User> example = Example.of(dtoToUser(userDto), examplematcher);
		Pageable pagebale = PageRequest.of(pn, pageSize, Sort.Direction.ASC, sortBy);
		Page<User> findAll = this.userRepo.findAll(example, pagebale);
		List<User> content = findAll.getContent();
		List<UserResponse> dtoList = new ArrayList<>();
		for (User u : content) {
			for(UserRole ur : u.getUserRole())
			{
				if(ur.getRole().getRoleName().equals("OWNER"))
					dtoList.add(userToDto(u));
			}
		}
		return dtoList;
	}

//	GET USER BY ID
	@Override
	public UserResponse getById(Long userId) {
		Optional<User> findById = this.userRepo.findById(userId);
		if(findById.isPresent())
		return userToDto(findById.get());
		
		else {
			throw new UserNotFoundException(AppConstant.USER_NOT_FOUND);
			
		}
	}
	
//	CHECK USER IS CUSTOMER OF NOT 
	@Override
	public Boolean isCustomer(Long customerId) {
		Optional<User> findById = this.userRepo.findById(customerId);
		if(findById.isPresent())
		{
			User user = findById.get();
			Set<UserRole> userRole = user.getUserRole();
			for(UserRole ur : userRole)
			{
				if(ur.getRole().getRoleName().equalsIgnoreCase("CUSTOMER"))
				{
					return true;
				}
				else
					return false;
			}
		}
		
			throw new UserNotFoundException(AppConstant.USER_NOT_FOUND);
	}
	
//	SOFT DELETE USER WITH USER ID
	@Override
	public UserResponse softDelete(Long userId) {
		Optional<User> findById = this.userRepo.findById(userId);
		if(findById.isPresent())
		{
			User user = findById.get();
			user.setIsActive(false);
			user.setUserId(userId);
			this.userRepo.save(user);
			return userToDto(user);
		}
		else
		{
			throw new UserNotFoundException("User Not Found");
		}
	}
	
//	REMOVE USER FROM SOFT DELETE
	@Override
	public UserResponse undoUser(Long userId) {
		Optional<User> findById = this.userRepo.findById(userId);
		if(findById.isPresent())
		{
			User user = findById.get();
			user.setIsActive(true);
			user.setUserId(userId);
			this.userRepo.save(user);
			return userToDto(user);
		}
		else
		{
			throw new UserNotFoundException("User Not Found");
		}
	}

	//* Convert Dto to User.... /
	public User dtoToUser(UserRequest userDto) {
		User user = this.modelmapper.map(userDto, User.class);
		return user;
	}

	//* Convert User to Dto.... /
	public UserResponse userToDto(User user) {
		UserResponse userdto = this.modelmapper.map(user, UserResponse.class);
		return userdto;
	}

	@Override
	public UserDetails loadUserByUsername(String useremail) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		
		Optional<User> user = this.userRepo.getUserByName(useremail);
		if(user.isEmpty()) 
		{
			throw new UserFoundException(AppConstant.USER_NOT_FOUND);
		}
		User u = user.get();
		List<GrantedAuthority> authorities = user.get().getUserRole().stream().map(role->new SimpleGrantedAuthority(role.getRole().getRoleName())).collect(Collectors.toList());
				
		return new org.springframework.security.core.userdetails.User(useremail, user.get().getPassword(), authorities);
	}

	@Override
	public User getCurrentUser(Principal p) {
		// TODO Auto-generated method stub	
		System.out.println("GET CURRENT USER");
		return this.userRepo.findByEmail(p.getName());
	}

	@Override
	public Integer getCoutOfAllCustomer() {
		// TODO Auto-generated method stub
		Integer count = 0;
		List<User> list = this.userRepo.findAll();
		for(User u:list)
		{
			Set<UserRole> userRole = u.getUserRole();
			for(UserRole ur : userRole)
			{
				if(ur.getRole().getRoleName().equalsIgnoreCase("CUSTOMER") )
				{
					count++;
				}
			}
		}
		return count;
	}

	@Override
	public Integer getCoutOfActiveCustomer() {
		// TODO Auto-generated method stub
		Integer count = 0;
		List<User> list = this.userRepo.findAll();
		for(User u:list)
		{
			Set<UserRole> userRole = u.getUserRole();
			for(UserRole ur : userRole)
			{
				if(ur.getRole().getRoleName().equalsIgnoreCase("CUSTOMER") && u.getIsActive()) {
					count++;
				}
			}
		}
		return count;
	}

	@Override
	public Integer getCoutOfInactiveCustomer() {
		Integer count = 0;
		List<User> list = this.userRepo.findAll();
		for(User u:list)
		{
			Set<UserRole> userRole = u.getUserRole();
			for(UserRole ur : userRole)
			{
				if(ur.getRole().getRoleName().equalsIgnoreCase("CUSTOMER") && (!u.getIsActive())) {
					count++;
				}
			}
		}
		return count;
	}

	@Override
	public Integer getCoutOfAllUsers() {
		// TODO Auto-generated method stub
		List<User> list = this.userRepo.findAll();
		return (Integer)list.size();
	}
}
