package com.adda.app.service;

import com.adda.app.dto.CategoryRequest;
import com.adda.app.dto.CategoryResponse;
import com.adda.app.paginationDto.PageCategoryResponse;

public interface ICategoryService {

	public CategoryResponse saveCategory(CategoryRequest category);
	public CategoryResponse updateCategory(CategoryRequest category ,Long catId);
	public CategoryResponse deleteCategory(Long id);
	CategoryResponse getCategoryById(Long catId);
	public PageCategoryResponse getAllCategory(int pn,int ps,String sortBy,CategoryRequest categoryRequest);
	public PageCategoryResponse getAllActiveCategory(int pn,int ps,String sortBy,CategoryRequest categoryRequest);
	public PageCategoryResponse getInActiveCategory(int pn,int ps,String sortBy,CategoryRequest categoryRequest);
	public PageCategoryResponse getAllCategoryOfRestaurent(int pn, int ps, String sortBy,Long resId);
	public PageCategoryResponse getAllActiveCategoryOfRestaurent(int pn, int ps, String sortBy,Long resId);
}
