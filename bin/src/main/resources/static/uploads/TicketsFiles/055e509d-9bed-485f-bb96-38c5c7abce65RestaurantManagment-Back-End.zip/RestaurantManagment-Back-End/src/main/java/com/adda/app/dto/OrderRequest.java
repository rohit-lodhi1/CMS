package com.adda.app.dto;

import com.adda.app.entity.User;
import com.adda.app.enums.OrderStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class OrderRequest {
	private Long orderId;
	private OrderStatus orderStatus;
	private User user;
}
