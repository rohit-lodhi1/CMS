package com.adda.app.reposatory;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.adda.app.entity.User;

public interface IUserRepo extends JpaRepository<User, Long> {
	
	User findByEmail(String email);
	@Query("SELECT u FROM User u WHERE u.email=:email")
	public Optional<User> getUserByName(String email);
}
