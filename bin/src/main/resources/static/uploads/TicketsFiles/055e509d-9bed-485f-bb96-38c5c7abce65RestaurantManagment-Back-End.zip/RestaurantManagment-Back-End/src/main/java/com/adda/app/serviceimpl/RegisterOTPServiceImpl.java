package com.adda.app.serviceimpl;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adda.app.entity.RegisterOTP;
import com.adda.app.exception.DuplicateEmail;
import com.adda.app.exception.NoValuePresentException;
import com.adda.app.exception.OtpTimeExpireException;
import com.adda.app.helper.AppConstant;
import com.adda.app.reposatory.RegisterOTPRepo;
import com.adda.app.service.IRegisterOTPService;

@Service
public class RegisterOTPServiceImpl implements IRegisterOTPService {

	@Autowired
	private RegisterOTPRepo repo;
	
	@Override
	public RegisterOTP saveOTP(RegisterOTP ro) {
		// TODO Auto-generated method stub
		Optional<RegisterOTP> optional = this.repo.findByEmail(ro.getEmail());
		if(optional.isPresent())
		{
			if(optional.get().getIsVerify())
			{
				throw new DuplicateEmail(AppConstant.DUPLICATE_EMAIL);
			}
			RegisterOTP otp = this.repo.save(ro);
			return otp;
			
		}
		RegisterOTP otp = this.repo.save(ro);
		return otp;
//		return null;
		
		
	}

	@Override
	public RegisterOTP updateOTP(RegisterOTP ro, Long Id) {
		// TODO Auto-generated method stub
		ro.setId(Id);
		Optional<RegisterOTP> optional = this.repo.findByEmail(ro.getEmail());
		if(optional.get().getIsVerify())
		{
			throw new DuplicateEmail(AppConstant.DUPLICATE_EMAIL);
		}
		RegisterOTP otp = this.repo.save(ro);
		return otp;
//		return null;
	}

	@Override
	public Boolean checkOTP(Integer otp,String email) {
		// TODO Auto-generated method stub
//		Optional<RegisterOTP> optional = repo.findByEmail(email);
		Optional<RegisterOTP> optional = this.repo.findByEmail(email);
		RegisterOTP registerOTP = optional.get();
		System.out.println(otp+"F OTP"+"  ===  DOTP "+registerOTP.getOtp()+"X");
		if(optional.isPresent())
		{
			if(optional.get().getIsVerify())
			{
				throw new DuplicateEmail(AppConstant.DUPLICATE_EMAIL);
			}
			else
			{
				Duration duration = Duration.between(registerOTP.getCreateDateTime(), LocalDateTime.now());
		        long minutesDifference = duration.toMinutes();
				if(minutesDifference < AppConstant.OTP_TIME_DIFERENCE)
				{
					if(registerOTP.getOtp().equals(otp))
						{
							RegisterOTP ro = new RegisterOTP(registerOTP.getId(), email, otp, true,LocalDateTime.now());
							this.updateOTP(ro, registerOTP.getId());
							System.out.println("CHECK OTP TRUE");
							return true;
						}
					else
					{
						System.out.println("CHECK OTP FALSE");
						return false;
					}
				}
				else
				{
					throw new OtpTimeExpireException(AppConstant.OTP_TIME_EXPIRE);
				}	
			}
		}
		throw new NoValuePresentException(AppConstant.NO_VALUE_PRESENT);
	}

	@Override
	public RegisterOTP ifEmailExist(String email) {
		Optional<RegisterOTP> optional = this.repo.findByEmail(email);
		if(optional.isEmpty())
		{
			return null;
		}
		else {
			return optional.get();
		}
	}

}
