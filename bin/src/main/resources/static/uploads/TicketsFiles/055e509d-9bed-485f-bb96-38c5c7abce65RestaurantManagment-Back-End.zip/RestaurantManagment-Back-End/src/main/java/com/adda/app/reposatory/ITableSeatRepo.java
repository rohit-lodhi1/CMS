package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.adda.app.entity.TableSeat;

public interface ITableSeatRepo extends JpaRepository<TableSeat, Long> {

	@Query("SELECT t FROM TableSeat t WHERE t.tableNo=:tNo AND t.restaurant.restId=:resId")
	 public TableSeat findByTableNo(Long tNo,Long resId);
}
