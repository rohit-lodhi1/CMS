package com.adda.app.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.dto.CartItemRequest;
import com.adda.app.dto.CartItemResponse;
import com.adda.app.service.ICartItemService;

@RestController
@RequestMapping("/api/item")
public class CartItemController {
    @Autowired
	private ICartItemService itemService;
	@PostMapping("/add")
	public ResponseEntity<CartItemResponse> createCart(@RequestBody CartItemRequest cartItemRequest)
	{
	  return new ResponseEntity<CartItemResponse>(this.itemService.addItemToCart(cartItemRequest),HttpStatus.OK);	
	}
	@GetMapping("/remove/{fId}")
	public void  removeItemFromCart(@PathVariable Long fId,Principal p)
	{
	 	this.itemService.decreseQuantityItemFromCart(fId, p);
	}
	
}
