package com.adda.app.exception;

public class CategoryNotFoundException extends RuntimeException{

	public CategoryNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CategoryNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
