package com.adda.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.dto.BookSeatRequest;
import com.adda.app.dto.BookSeatResponse;
import com.adda.app.enums.BookingStatus;
import com.adda.app.service.IBookSeatService;
@RestController
@RequestMapping("/customer/bookseat")
public class BookedSeatController {

	@Autowired
	private IBookSeatService service;
//	@Autowired
//	private  INotificationService notificationService;
//	
	@PostMapping("/book")
	public ResponseEntity<String> bookSeat(@RequestBody BookSeatRequest bookSeatRequest)
	{
		BookSeatResponse b = service.bookTable(bookSeatRequest);
		if(b.getStatus()==BookingStatus.CONFIRMED) 
		{
		//	 notificationService.notifyAdminAndOwner("New table booking received! Table: " + bookSeatRequest.getTable().getTableNo());
        }
		
		return new ResponseEntity<String>("table booked succcessfully",HttpStatus.CREATED);
	}
}
