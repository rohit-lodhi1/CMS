package com.adda.app.service;

import com.adda.app.entity.RegisterOTP;

public interface IRegisterOTPService {

	RegisterOTP saveOTP(RegisterOTP ro);
	
	RegisterOTP updateOTP(RegisterOTP ro, Long Id);
	
	Boolean checkOTP(Integer otp,String email);
	
	RegisterOTP ifEmailExist(String email);
}
