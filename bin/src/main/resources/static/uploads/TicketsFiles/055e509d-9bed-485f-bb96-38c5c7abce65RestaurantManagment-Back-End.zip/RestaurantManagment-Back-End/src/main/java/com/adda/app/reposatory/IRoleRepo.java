package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adda.app.entity.Role;

public interface IRoleRepo extends JpaRepository<Role, Long> {

}
