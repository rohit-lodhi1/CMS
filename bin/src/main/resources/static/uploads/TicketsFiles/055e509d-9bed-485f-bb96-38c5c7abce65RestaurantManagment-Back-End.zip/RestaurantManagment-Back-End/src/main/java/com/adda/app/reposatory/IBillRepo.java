package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adda.app.entity.Bill;

public interface IBillRepo extends JpaRepository<Bill, Long>{

}
