package com.adda.app.service;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

import com.adda.app.dto.FoodRequest;
import com.adda.app.dto.FoodResponse;
import com.adda.app.paginationDto.PageFoodResponse;



public interface IFoodService {

	public String saveFood(MultipartFile file,FoodRequest foodRequest,String path) throws IOException;
	public String updateFood(FoodRequest foodRequest,Long fid ,MultipartFile file ,String path) throws IOException;
	public FoodResponse deleteFood(Long id);
	public PageFoodResponse viewAllFood(int pn,int pageSize,String sortBy,FoodRequest request);
	public PageFoodResponse viewAllActiveFood(int pn,int pageSize,String sortBy,FoodRequest request);
	public FoodResponse undoFood(Long fid);
}
