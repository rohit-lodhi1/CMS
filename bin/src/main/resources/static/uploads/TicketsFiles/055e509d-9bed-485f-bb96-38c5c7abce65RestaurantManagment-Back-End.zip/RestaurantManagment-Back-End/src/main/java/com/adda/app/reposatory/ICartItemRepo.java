package com.adda.app.reposatory;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.adda.app.entity.CartItem;
import com.adda.app.entity.Food;

public interface ICartItemRepo extends JpaRepository<CartItem, Long> {

	@Query("SELECT c FROM CartItem c WHERE c.cart.id = :cid")
	List<CartItem> findByCartId(Long cid);

	CartItem findCartItemByFood(Food food);
    @Query("SELECT c FROM CartItem c WHERE c.food.foodId =:fId AND c.cart.id =:cartId")
	CartItem getCartItemByFoodIdAndCartId(Long fId, Long cartId);
}
