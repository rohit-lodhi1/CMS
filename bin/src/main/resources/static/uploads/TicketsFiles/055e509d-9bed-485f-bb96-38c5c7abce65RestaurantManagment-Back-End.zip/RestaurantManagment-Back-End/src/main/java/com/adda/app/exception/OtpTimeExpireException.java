package com.adda.app.exception;

public class OtpTimeExpireException extends RuntimeException {

	public OtpTimeExpireException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OtpTimeExpireException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
