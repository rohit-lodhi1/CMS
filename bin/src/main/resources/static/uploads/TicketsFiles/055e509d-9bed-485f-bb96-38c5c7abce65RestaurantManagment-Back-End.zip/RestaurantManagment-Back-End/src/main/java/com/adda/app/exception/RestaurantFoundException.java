package com.adda.app.exception;

public class RestaurantFoundException extends RuntimeException{

	public RestaurantFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RestaurantFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
