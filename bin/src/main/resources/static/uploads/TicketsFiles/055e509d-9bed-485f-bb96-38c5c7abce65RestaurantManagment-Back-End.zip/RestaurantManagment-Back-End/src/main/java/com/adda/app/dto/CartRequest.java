package com.adda.app.dto;

import java.util.List;

import com.adda.app.entity.CartItem;
import com.adda.app.entity.User;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CartRequest {

	
	private Long id;

	private User user;
	
	private List<CartItem> cartitem;
}
