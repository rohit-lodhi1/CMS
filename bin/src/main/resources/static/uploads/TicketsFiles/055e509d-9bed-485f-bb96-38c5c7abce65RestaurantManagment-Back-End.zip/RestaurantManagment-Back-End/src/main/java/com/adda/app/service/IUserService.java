package com.adda.app.service;

import java.security.Principal;
import java.util.List;

import com.adda.app.dto.UserRequest;
import com.adda.app.dto.UserResponse;
import com.adda.app.entity.User;
import com.adda.app.exception.UserFoundException;

public interface IUserService {

	UserResponse createUser(UserRequest user)throws UserFoundException ;
	
	UserResponse updateUser(UserRequest user,Long userId)throws UserFoundException ;
	
	UserResponse findByEmail(String email);
	
	UserResponse findByUserId(Long userId);
	
	List<UserResponse> findAllUser(int pn,int pageSize,String sortBy,UserRequest userDto);
	
	List<UserResponse> findAllActiveUser(int pn, int pageSize, String sortBy, UserRequest userDto);
	
	List<UserResponse> findAllCustomer(int pn, int pageSize, String sortBy, UserRequest userDto);
	
	List<UserResponse> findAllAdmin(int pn, int pageSize, String sortBy, UserRequest userDto);
	
	List<UserResponse> findAllDeliveryBoy(int pn, int pageSize, String sortBy, UserRequest userDto);
	
	List<UserResponse> findAllRestaurantOwner(int pn, int pageSize, String sortBy, UserRequest userDto);
	
	UserResponse getById(Long userId);
	
	UserResponse softDelete(Long userId);
	
	public Boolean isCustomer(Long customerId) ;
	
	UserResponse undoUser(Long userId);

	User getCurrentUser(Principal p);
	
	Integer getCoutOfAllCustomer();
	
	Integer getCoutOfActiveCustomer();
	
	Integer getCoutOfInactiveCustomer();
	
	Integer getCoutOfAllUsers();
	
	
	
}
