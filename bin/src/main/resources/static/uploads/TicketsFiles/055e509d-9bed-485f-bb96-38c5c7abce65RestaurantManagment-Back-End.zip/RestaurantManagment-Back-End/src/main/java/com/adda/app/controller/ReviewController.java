package com.adda.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.dto.ReviewRequest;
import com.adda.app.dto.ReviewResponse;
import com.adda.app.service.IReviewService;

@RestController
@RequestMapping("/review")
@CrossOrigin("*")
public class ReviewController {
	
	@Autowired
	private IReviewService reviewService;
	
	@PostMapping("/save")
	public ResponseEntity<ReviewResponse> createReview(@RequestBody ReviewRequest reviewReq)
	{
		return new ResponseEntity<ReviewResponse>(this.reviewService.saveReview(reviewReq),HttpStatus.CREATED);
	}
	
	@PutMapping("/update/{reviewId}")
	public ResponseEntity<ReviewResponse> updateReview(@RequestBody ReviewRequest reviewReq,@PathVariable Long reviewId)
	{
		return new ResponseEntity<ReviewResponse>(this.reviewService.updateReview(reviewReq, reviewId),HttpStatus.OK);
	}
	
	@GetMapping("/getAllReview/{pn}/{ps}/{sortBy}")
	public ResponseEntity<List<ReviewResponse>> getAllReview(@PathVariable int pn , @PathVariable int ps , @PathVariable String sortBy , @RequestBody ReviewRequest reviewReq)
	{
		return new ResponseEntity<List<ReviewResponse>>(this.reviewService.getAllReview(pn, ps, sortBy,reviewReq ),HttpStatus.OK);
	}
	
	@GetMapping("/getAllReviewOfRestaurant/{pn}/{ps}/{sortBy}/{restId}")
	public ResponseEntity<List<ReviewResponse>> getAllReviewOfRestaurant(@PathVariable int pn , @PathVariable int ps , @PathVariable String sortBy , @RequestBody ReviewRequest reviewReq,@PathVariable Long restId)
	{
		return new ResponseEntity<List<ReviewResponse>>(this.reviewService.getAllReviewOfRestaurant(pn, ps, sortBy,reviewReq ,restId),HttpStatus.OK);
	}
	
	@GetMapping("/getAllReviewOfCustomer/{customerId}")
	public ResponseEntity<List<ReviewResponse>> getAllReviewOfCustomer(@PathVariable Long customerId)
	{
		return new ResponseEntity<List<ReviewResponse>>(this.reviewService.getAllReviewOfCustomer(customerId),HttpStatus.OK);
	}

	@DeleteMapping("/delete/{reviewId}")
	public ResponseEntity<String>  deleteReview(@PathVariable Long reviewId)
	{
		return new ResponseEntity<String>(this.reviewService.deleteReview(reviewId),HttpStatus.OK);
	}
}
