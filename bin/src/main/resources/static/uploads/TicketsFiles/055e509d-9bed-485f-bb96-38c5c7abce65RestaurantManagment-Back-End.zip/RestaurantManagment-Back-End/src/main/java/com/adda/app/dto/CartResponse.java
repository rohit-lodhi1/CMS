package com.adda.app.dto;

import java.util.List;

import com.adda.app.entity.CartItem;
import com.adda.app.entity.User;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CartResponse {
	private Long id;
    @JsonIgnore
	private User user;
	private List<CartItem> cartitem;
}
