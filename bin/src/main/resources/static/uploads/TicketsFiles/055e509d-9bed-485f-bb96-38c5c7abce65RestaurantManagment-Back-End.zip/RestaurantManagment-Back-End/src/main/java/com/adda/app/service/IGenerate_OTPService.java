package com.adda.app.service;

public interface IGenerate_OTPService {

	public Integer generate_OTP();
}
