package com.adda.app.service;

import java.security.Principal;
import java.util.List;

import com.adda.app.dto.CartItemResponse;
import com.adda.app.dto.CartResponse;

public interface ICartService {

	public CartResponse createCart(Principal p);
	public List<CartItemResponse> checkCart(Principal p);
}
