package com.adda.app.dto;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.adda.app.entity.Address;
import com.adda.app.entity.Bill;
import com.adda.app.entity.Cart;
import com.adda.app.entity.Review;
import com.adda.app.entity.UserRole;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class UserRequest {
	 private Long userId;
	   private String firstName;
	   private String lastName;
	   private String email;
	   private String password;
	 
	   private String mob;
	   private String tempAddress;
	   private String tempRole;
	   private Boolean isActive;
	   private Set<UserRole> userRole=new HashSet<>();
//	   @OneToMany(mappedBy = "user")
	   private Set<Address> address=new HashSet<>();
//	   @OneToOne(mappedBy = "user")
	   private Cart cart;
//	   @OneToOne(mappedBy = "user")
	   private Bill bill;
	   private List<Review> listofReview;
}
