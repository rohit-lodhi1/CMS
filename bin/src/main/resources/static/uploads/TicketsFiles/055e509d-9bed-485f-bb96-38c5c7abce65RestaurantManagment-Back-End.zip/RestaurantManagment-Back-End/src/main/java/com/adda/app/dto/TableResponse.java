package com.adda.app.dto;

import java.util.ArrayList;
import java.util.List;

import com.adda.app.entity.BookedSeat;
import com.adda.app.entity.Restaurant;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class TableResponse {
	private Long tableId;
	private Long tableNo;
	private String tableCapacity;
	private Boolean isActive;
	//@OneToMany(mappedBy = "table")
	@JsonIgnore
	private Restaurant restaurant;
	@JsonIgnore
	private List<BookedSeat> bookSeat = new ArrayList<>();
}
