package com.adda.app.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.adda.app.dto.RestaurantRequest;
import com.adda.app.dto.RestaurantResponse;
import com.adda.app.entity.Restaurant;
import com.adda.app.paginationDto.PageRestaurantResponse;

public interface IRestaurantService {

   
	public RestaurantResponse saveRestaurant(RestaurantRequest restaurantResponse);
	public RestaurantResponse updateRestaurant(RestaurantRequest restaurantResponse,Long resId);
	public RestaurantResponse deleteRestaurant(long id);
	public Page<RestaurantResponse> viewAllRestaurant(int pageno,int pageSize,String sortBy,RestaurantRequest request);
	public PageRestaurantResponse  viewAllActiveRestaurant(int pageno,int pageSize,String sortBy,RestaurantRequest request);
	public PageRestaurantResponse  viewAllInctiveRestaurant(int pageno,int pageSize,String sortBy,RestaurantRequest request);
	public List<Restaurant> all();
	RestaurantResponse undoRestaurant(Long restId);
	
	Integer getCountingOfAllRestaurant();
	Integer getCountingOfActiveRestaurant();
}
