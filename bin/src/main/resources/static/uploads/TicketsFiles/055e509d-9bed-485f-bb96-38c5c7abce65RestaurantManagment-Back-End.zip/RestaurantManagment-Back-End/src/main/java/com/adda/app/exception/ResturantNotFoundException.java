package com.adda.app.exception;

public class ResturantNotFoundException extends RuntimeException{

	public ResturantNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResturantNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
