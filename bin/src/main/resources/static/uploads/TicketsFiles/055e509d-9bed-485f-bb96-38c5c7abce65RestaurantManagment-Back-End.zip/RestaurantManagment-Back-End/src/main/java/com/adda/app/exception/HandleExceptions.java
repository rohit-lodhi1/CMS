package com.adda.app.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class HandleExceptions {

	
	/**Category found exception*/
	@ExceptionHandler(CategoryFoundException.class)
	public ResponseEntity<CustomMsgForException>CategoryFoundException(CategoryFoundException c)
	{
		return new ResponseEntity<CustomMsgForException>(new CustomMsgForException(new Date().toString(),500,"Exception in Process...",c.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	/** user found Exception*/
	@ExceptionHandler(UserFoundException.class)
	public ResponseEntity<CustomMsgForException>UserFoundException(UserFoundException c)
	{
		return new ResponseEntity<CustomMsgForException>(new CustomMsgForException(new Date().toString(),500,"Exception in Process...",c.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	/** restaurant found exception*/
	@ExceptionHandler(RestaurantFoundException.class)
	public ResponseEntity<CustomMsgForException>RestaurantFoundException(RestaurantFoundException c)
	{
		return new ResponseEntity<CustomMsgForException>(new CustomMsgForException(new Date().toString(),500,"Exception in Process...",c.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	/**food found Exception*/
	@ExceptionHandler(FoodFoundException.class)
	public ResponseEntity<CustomMsgForException>FoodFoundException(FoodFoundException c)
	{
		return new ResponseEntity<CustomMsgForException>(new CustomMsgForException(new Date().toString(),500,"Exception in Process...",c.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	/** user not found exception*/
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<CustomMsgForException>UserNotFoundException(UserNotFoundException c)
	{
		return new ResponseEntity<CustomMsgForException>(new CustomMsgForException(new Date().toString(),500,"Exception in Process...",c.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	/**Restaurant not found Exception*/
	@ExceptionHandler(ResturantNotFoundException.class)
	public ResponseEntity<CustomMsgForException>ResturantNotFoundException(ResturantNotFoundException c)
	{
		return new ResponseEntity<CustomMsgForException>(new CustomMsgForException(new Date().toString(),500,"Exception in Process...",c.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	/**Food not found Exception*/
	@ExceptionHandler(FoodNotFoundException.class)
	public ResponseEntity<CustomMsgForException>FoodNotFoundException(FoodNotFoundException c)
	{
		return new ResponseEntity<CustomMsgForException>(new CustomMsgForException(new Date().toString(),500,"Exception in Process...",c.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	/**Category not found Exception*/
	@ExceptionHandler(CategoryNotFoundException.class)
	public ResponseEntity<CustomMsgForException>CategoryNotFoundException(CategoryNotFoundException c)
	{
		return new ResponseEntity<CustomMsgForException>(new CustomMsgForException(new Date().toString(),500,"Exception in Process...",c.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	/**Resource not found Exception Exception*/
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<CustomMsgForException>RestaurantNotFound(ResourceNotFoundException c)
	{
		return new ResponseEntity<CustomMsgForException>(new CustomMsgForException(new Date().toString(),500,"Exception in Process...",c.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
}
