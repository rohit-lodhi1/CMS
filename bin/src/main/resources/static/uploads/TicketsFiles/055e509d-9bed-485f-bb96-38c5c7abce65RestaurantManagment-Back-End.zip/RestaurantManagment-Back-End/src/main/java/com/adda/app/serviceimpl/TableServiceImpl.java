package com.adda.app.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.StringMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.adda.app.dto.TableRequest;
import com.adda.app.dto.TableResponse;
import com.adda.app.entity.TableSeat;
import com.adda.app.exception.ResourceNotFoundException;
import com.adda.app.helper.AppConstant;
import com.adda.app.reposatory.ITableSeatRepo;
import com.adda.app.service.ITableService;
@Service
public class TableServiceImpl implements ITableService {
   @Autowired
	private ITableSeatRepo trepo;
   @Autowired
    private ModelMapper mapper;
		
	@Override
	public TableResponse saveTable(TableRequest tableRequest) {
		// TODO Auto-generated method stub
		TableSeat tableSeat  =  this.trepo.findByTableNo(tableRequest.getTableNo(),tableRequest.getRestaurant().getRestId());
		if(tableSeat!=null) 
		{
			throw new ResourceNotFoundException(AppConstant.TABLE_ALREADY_EXIST);
		}else 
		{
		return this.tableToTableResponse(this.trepo.save(this.TableRequestToTable(tableRequest)));
		}
	
	}
	@Override
	public TableResponse updateTable(TableRequest tableRequest, Long tId) {
		// TODO Auto-generated method stub
	
		TableSeat table = this.TableRequestToTable(tableRequest);
		Optional<TableSeat> tableSeat = this.trepo.findById(tId);
	
		
	    if(tableSeat.isEmpty()) 
		{
	    	
			throw new ResourceNotFoundException(AppConstant.TABLE_NOT_FOUND);
		}
	    else 
		{ 
	    	table.setTableNo(tableSeat.get().getTableNo());
			table.setTableId(tId);
			System.out.println("...");
			return this.tableToTableResponse(this.trepo.save(table));
		
		}
		
	}
	@Override
	public TableResponse deleteTable(Long id) {
		// TODO Auto-generated method stub
		Optional<TableSeat> tableSeat = this.trepo.findById(id);
		if(tableSeat.isEmpty()) 
		{
			throw new ResourceNotFoundException(AppConstant.TABLE_NOT_FOUND);
		}else 
		{
			TableSeat tableSeat2 = tableSeat.get();
			tableSeat2.setTableId(id);
			tableSeat2.setIsActive(false);
			return this.tableToTableResponse(this.trepo.save(tableSeat2));
		}
		
	}
	@Override
	public TableResponse undoTable(Long tId) {
		// TODO Auto-generated method stub
		Optional<TableSeat> tableSeat = this.trepo.findById(tId);
		if(tableSeat.isPresent()) 
		{
			TableSeat tableSeat2 = tableSeat.get();
			tableSeat2.setIsActive(true);
			tableSeat2.setTableId(tId);
			return this.tableToTableResponse(this.trepo.save(tableSeat2));
		}
		else 
		{
			throw new ResourceNotFoundException(AppConstant.TABLE_NOT_FOUND);
		}
		
	}
	@Override
	public List<TableResponse> viewAllTable(int pn, int ps, String sortby, TableRequest tableRequest) {
		// TODO Auto-generated method stub
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(StringMatcher.EXACT.CONTAINING)
				.withIgnoreCase()
				.withMatcher("tId", match->match.transform(value->value.map(id->((Long)id==0)?null:id)));
		Example<TableSeat> example = Example.of(TableRequestToTable(tableRequest),exampleMatcher);
		Pageable pageable = PageRequest.of(pn, ps,Sort.Direction.ASC,sortby);
		Page<TableSeat> findAllTable = this.trepo.findAll(example, pageable);
		return findAllTable.getContent().stream().map(t->tableToTableResponse(t)).collect(Collectors.toList());
	}
	
	/**TableRequest convert tableSeat*/
	public TableSeat TableRequestToTable(TableRequest tableRequest) 
	{
		return this.mapper.map(tableRequest, TableSeat.class);
	}
	/**Table convert tableResponse*/
	public TableResponse tableToTableResponse(TableSeat tableSeat) 
	{
		return this.mapper.map(tableSeat, TableResponse.class);
	}
	
}
