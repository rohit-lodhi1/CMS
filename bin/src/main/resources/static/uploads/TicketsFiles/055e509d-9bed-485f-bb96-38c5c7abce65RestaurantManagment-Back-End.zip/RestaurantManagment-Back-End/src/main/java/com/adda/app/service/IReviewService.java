package com.adda.app.service;

import java.util.List;

import com.adda.app.dto.ReviewRequest;
import com.adda.app.dto.ReviewResponse;

public interface IReviewService {

	public ReviewResponse saveReview(ReviewRequest reviewReq);
	
	public ReviewResponse updateReview(ReviewRequest reviewReq,Long reviewId);
	
	public List<ReviewResponse> getAllReview(int pn, int ps, String sortBy, ReviewRequest reviewRequest);
	
	public String deleteReview(Long reviewId);
	
	public List<ReviewResponse> getAllReviewOfRestaurant(int pn, int ps, String sortBy, ReviewRequest reviewRequest,Long restId);
	
	public List<ReviewResponse> getAllReviewOfCustomer(Long customerId);
}
