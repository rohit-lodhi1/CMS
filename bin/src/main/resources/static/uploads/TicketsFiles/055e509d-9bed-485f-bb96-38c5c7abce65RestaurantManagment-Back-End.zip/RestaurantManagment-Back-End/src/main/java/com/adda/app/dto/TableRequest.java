package com.adda.app.dto;

import java.util.ArrayList;
import java.util.List;

import com.adda.app.entity.BookedSeat;
import com.adda.app.entity.Restaurant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class TableRequest {
	private Long tableId;
	private Long tableNo;
	private String tableCapacity;
	private Boolean isActive;
	//@OneToMany(mappedBy = "table")
	private Restaurant restaurant;
	private List<BookedSeat> bookSeat = new ArrayList<>();
}
