package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adda.app.entity.Cart;
import com.adda.app.entity.User;

public interface ICartRepo extends JpaRepository<Cart, Long> {

	public Cart  findByUser(User user);
   
}
