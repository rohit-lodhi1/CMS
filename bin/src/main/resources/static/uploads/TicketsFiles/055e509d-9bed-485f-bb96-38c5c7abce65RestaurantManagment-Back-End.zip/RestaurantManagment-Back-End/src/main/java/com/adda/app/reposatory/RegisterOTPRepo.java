package com.adda.app.reposatory;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adda.app.entity.RegisterOTP;

public interface RegisterOTPRepo extends JpaRepository<RegisterOTP, Long> {

//	@Query("SELECT u FROM User u WHERE u.email=:email")
	Optional<RegisterOTP> findByEmail(String email);
//	@Query("SELECT u FROM User u WHERE u.email = :email")
//	RegisterOTP findByEmail(@Param("email") String email);
}
