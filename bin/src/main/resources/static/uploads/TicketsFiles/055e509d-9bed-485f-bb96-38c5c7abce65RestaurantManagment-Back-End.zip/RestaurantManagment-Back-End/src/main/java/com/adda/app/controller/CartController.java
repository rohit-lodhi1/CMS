package com.adda.app.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.dto.CartItemResponse;
import com.adda.app.dto.CartResponse;
import com.adda.app.service.ICartService;
import com.adda.app.service.IUserService;

@RestController
@RequestMapping("/api/cart")
public class CartController {

	@Autowired
	private ICartService cservice;
	@Autowired
	private IUserService uservice;
	
	@PostMapping("/save")
	public ResponseEntity<CartResponse> createCart(Principal p)
	{
		
		return new ResponseEntity<CartResponse>(this.cservice.createCart(p),HttpStatus.CREATED);
	}
	
	@GetMapping("/view-cart")
	public ResponseEntity<List<CartItemResponse>> checkCart(Principal p)
	{
		return new ResponseEntity<List<CartItemResponse>>(this.cservice.checkCart(p),HttpStatus.OK);
	}
}
