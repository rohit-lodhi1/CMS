package com.adda.app.dto;

import java.util.ArrayList;
import java.util.List;

import com.adda.app.entity.Category;
import com.adda.app.entity.Food;
import com.adda.app.entity.Review;
import com.adda.app.entity.Waiter;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class RestaurantRequest {

	private Long restId;

	private String restName;

	private String restCloseTime;

	private String restOpentime;

	private Boolean restTableStatus;

	private Boolean restPickupStatus;

	private Boolean deliveryStatus;

	private Boolean isActive;

	private Boolean waiterStatus;

	private Boolean currentStatus;

	private String Address;

	private String restDescription;

	private String createdAt;

	private String lat;

	private String longg;
	
	//@OneToMany(mappedBy = "restaurant")
	private List<Food> listOfFood;
	
	//@OneToMany(mappedBy = "restaurant")
	private List<Category> listOfCategory;
	
	//@OneToMany(mappedBy = "restaurant")
	private List<Waiter> listOfWaiter;
	
	//@OneToMany(mappedBy = "rest")
	private List<Review> listofReview = new ArrayList<>();
}
