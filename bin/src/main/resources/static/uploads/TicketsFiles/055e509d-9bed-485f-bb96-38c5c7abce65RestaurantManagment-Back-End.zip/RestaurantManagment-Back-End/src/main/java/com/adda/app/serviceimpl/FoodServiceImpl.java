package com.adda.app.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.StringMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.adda.app.dto.FoodRequest;
import com.adda.app.dto.FoodResponse;
import com.adda.app.entity.Category;
import com.adda.app.entity.Food;
import com.adda.app.exception.FoodFoundException;
import com.adda.app.exception.FoodNotFoundException;
import com.adda.app.helper.AppConstant;
import com.adda.app.paginationDto.PageFoodResponse;
import com.adda.app.replica.foodReplica;
import com.adda.app.reposatory.ICategoryRepo;
import com.adda.app.reposatory.IFoodReplicaRepo;
import com.adda.app.reposatory.IFoodRepo;
import com.adda.app.service.IFoodService;
@Service
public class FoodServiceImpl implements IFoodService {

	/**
	 * Autowire Food Reposatory....*/
	@Autowired
	private IFoodRepo frepo;
	/** Autowire Category Reposatory....*/
	@Autowired
	private ICategoryRepo crepo;
	/**Autowirw Food Replica reposatory...*/
	@Autowired
	private IFoodReplicaRepo replica_repo;
	/**Autowire Moddelmapper */
	@Autowired
	private ModelMapper modelMapper;
	
	
	@Override
	public String saveFood(MultipartFile file, FoodRequest foodRequest,String path) throws IOException {
		// TODO Auto-generated method stub
	String name = file.getOriginalFilename();
	String randomId = UUID.randomUUID().toString();
	String filename1 = randomId.concat(name.substring(name.lastIndexOf(".")));
	String filepath = path+File.separator+filename1;
	File f = new File(path);
	if(!f.exists()) 
	{
		f.mkdir();
	}
	Files.copy(file.getInputStream(), Paths.get(filepath));
	String imagename=filename1;
	
	
	//foodRequest.setImageName(imagename);
	Food f3 = this.resquestToFood(foodRequest);
	List<Food> listOfFoodByResto = f3.getRestaurant().getListOfFood(); 
	for(Food food :listOfFoodByResto) 
	{
	  if(f3.getFoodName().equalsIgnoreCase(food.getFoodName()))
	  {
		  throw new FoodFoundException(AppConstant.FOUND_FOUND);
	  }	
	}
	 f3.setFoodCreatedAt(new Date().toString());
     Category c = crepo.findCatnameByCatId(f3.getCategory().getCatId());
     f3.setFoodCategoryName(c.getCatName());
     f3.setImageName(imagename);
   FoodResponse r = this.foodToResponse(frepo.save(f3));
   //save data in food replica...
   foodReplica food_rep = new foodReplica(f3.getFoodName(),f3.getFoodPrice(),f3.getFoodCreatedAt(),f3.getIsAvailable(),f3.getFoodCategoryName(),f3.getRestaurant().getRestId(),f3.getCategory().getCatId());
   this.replica_repo.save(food_rep);
   
	if(r!=null) 
	{
		return "success";
	}
	return "failed";
	}
	
	
	

	
	
	/* update Food...*/
	
	
	@Override
	public String updateFood(FoodRequest foodRequest, Long fid, MultipartFile file, String path) throws IOException {
		// TODO Auto-generated method stub
		String name = file.getOriginalFilename();
		String randomId = UUID.randomUUID().toString();
		String filename1 = randomId.concat(name.substring(name.lastIndexOf(".")));
		String filepath = path+File.separator+filename1;
		File f = new File(path);
		if(!f.exists()) 
		{
			f.mkdir();
		}
		Files.copy(file.getInputStream(), Paths.get(filepath));
		String imagename=filename1;
		//foodRequest.setImageName(imagename);
		Food f3 = this.resquestToFood(foodRequest);
		List<Food> listOfFoodByResto = f3.getRestaurant().getListOfFood(); 
		for(Food food :listOfFoodByResto) 
		{
		  if(f3.getFoodName().equalsIgnoreCase(food.getFoodName()))
		  {
			  throw new FoodFoundException(AppConstant.FOUND_FOUND);
		  }	
		}
		 f3.setFoodCreatedAt(new Date().toString());
	     Category c = crepo.findCatnameByCatId(f3.getCategory().getCatId());
	     f3.setFoodCategoryName(c.getCatName());
	     f3.setImageName(imagename);
	   FoodResponse r = this.foodToResponse(frepo.save(f3));
	   //save data in food replica...
	   foodReplica food_rep = new foodReplica(f3.getFoodName(),f3.getFoodPrice(),f3.getFoodCreatedAt(),f3.getIsAvailable(),f3.getFoodCategoryName(),f3.getRestaurant().getRestId(),f3.getCategory().getCatId());
	   this.replica_repo.save(food_rep);
	   
		if(r!=null) 
		{
			return "success";
		}
		return "failed";
		}
		
		
	

	
	
	
	/**delete Food...*/
	@Override
	public FoodResponse deleteFood(Long id) {
		// TODO Auto-generated method stub
		Optional<Food> food = this.frepo.findById(id);
		if(food.isEmpty()) 
		{
			throw new FoodNotFoundException(AppConstant.FOOD_NOT_FOUND);
		}
		else 
		{
			Food f = food.get();
			f.setIsAvailable(false);
			f.setFoodId(id);
			return this.foodToResponse(f);
		}
	}
	
	@Override
	public PageFoodResponse viewAllFood(int pn, int pageSize, String sortBy, FoodRequest request) {
		// TODO Auto-generated method stub
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(StringMatcher.EXACT.CONTAINING)
				.withIgnoreCase()
				.withMatcher("rest_id", match->match.transform(value->value.map(id->((Integer)id==0)?null:id)));
		Example<Food> example = Example.of(resquestToFood(request), exampleMatcher);
		Pageable pagebale = PageRequest.of(pn, pageSize, Sort.Direction.ASC, sortBy);
		Page<Food> findAll = this.frepo.findAll(example, pagebale);
		List<FoodResponse> content = findAll.getContent().stream().map(c->foodToResponse(c)).collect(Collectors.toList());
		PageFoodResponse pfr = new PageFoodResponse();
		content.sort((o1, o2)
                 -> o1.getFoodPrice().compareTo(
                     o2.getFoodPrice()));
		pfr.setContents(content);
		pfr.setTotalElements(findAll.getTotalElements());
		
		return pfr;
	}


	@Override
	public PageFoodResponse viewAllActiveFood(int pn, int pageSize, String sortBy, FoodRequest request) {
		// TODO Auto-generated method stub
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(StringMatcher.EXACT.CONTAINING)
				.withIgnoreCase()
				.withMatcher("food_id", match->match.transform(value->value.map(id->((Integer)id==0)?null:id)));
		Example<Food> example = Example.of(resquestToFood(request), exampleMatcher);
		Pageable pagebale = PageRequest.of(pn, pageSize, Sort.Direction.ASC, sortBy);
		Page<Food> findAll = this.frepo.findAll(example, pagebale);
		List<FoodResponse> collect = findAll.getContent().stream().map(f -> foodToResponse(f)).collect(Collectors.toList());
		List<FoodResponse> list = new ArrayList<>();
		for(FoodResponse fs : collect)
		{
			if(fs.getIsAvailable())
			{
				list.add(fs);
			}
		}
		PageFoodResponse pfr = new PageFoodResponse();
		pfr.setContents(list);
		
		pfr.setTotalElements(Long.valueOf(list.size()));
		return pfr;
	}	
	
	
	
	@Override
	public FoodResponse undoFood(Long fid) {
		// TODO Auto-generated method stub
		Optional<Food> food = this.frepo.findById(fid);
		if(food.isPresent()) 
		{
			Food f = food.get();
			f.setIsAvailable(true);
			f.setFoodId(fid);
			return  foodToResponse(frepo.save(f));
		}
		else 
		{
		 throw new FoodNotFoundException(AppConstant.FOOD_NOT_FOUND);	
		}
		
	}
	/**Convert  Food To FoodResponse...*/
	public FoodResponse foodToResponse(Food food) 
	{
		return this.modelMapper.map(food, FoodResponse.class);
	}
	/**Convert  FoodResponse To Food...*/
	public Food resquestToFood(FoodRequest foodRequest) 
	{
		return this.modelMapper.map(foodRequest, Food.class);
	}
	/**Convert Food To FoodReplica*/
	public foodReplica foodToReplica(Food food) 
	{
		return this.modelMapper.map(food, foodReplica.class);
	}




	
	

	
	

	

	

	
}
