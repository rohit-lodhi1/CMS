package com.adda.app.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.adda.app.dto.FoodRequest;
import com.adda.app.dto.FoodResponse;
import com.adda.app.entity.Category;
import com.adda.app.entity.Restaurant;
import com.adda.app.paginationDto.PageFoodResponse;
import com.adda.app.service.IFoodService;

@RestController
@RequestMapping("/admin/food")
@CrossOrigin("*")
public class FoodController {
	
	/* Autowire Food Service...*/
    @Autowired
	private IFoodService service;
    private String path="image/";
    
    /*  Create Food*/
    
    @PostMapping("/uploadfood")
    public ResponseEntity<?> saveFood(@RequestParam("foodName") String foodname,
                                                   @RequestParam("foodPrice") Long price,
                                                   @RequestParam("foodimage") MultipartFile file,
                                                   @RequestParam("isAvailable") Boolean b,
                                                   @RequestParam("restaurant") Restaurant r,
                                                   @RequestParam("category")Category c
    		                                       ) throws IOException
    {
    	FoodRequest f = new FoodRequest(foodname,price,b,r,c);
    	String uploadfood = service.saveFood(file, f,path);
    return ResponseEntity.status(HttpStatus.OK).body(uploadfood);	
    
    }
    
   
    
    /*update Food*/
    @PutMapping("/update/{fid}")
    public ResponseEntity<?> updateFood(@RequestParam("foodName") String foodname,
            @RequestParam("foodPrice") Long price,
            @RequestParam("foodimage") MultipartFile file,
            @RequestParam("isAvailable") Boolean b,
            @RequestParam("restaurant") Restaurant r,
            @RequestParam("category")Category c,
            @PathVariable Long fid
           
            ) throws IOException
    {
    	System.out.println("...");
    	FoodRequest f = new FoodRequest(fid,foodname,price, b,r,c);
    	String updateFood = service.updateFood(f,fid,file,path);
    return ResponseEntity.status(HttpStatus.OK).body(updateFood);	
    }
    
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<FoodResponse> deleteFood(@PathVariable Long id)
    {
    	return new ResponseEntity<FoodResponse>(this.service.deleteFood(id),HttpStatus.OK);
    }
    /**get all food...*/
    @PostMapping("/all/{pn}/{ps}/{sortBy}")
    public ResponseEntity<PageFoodResponse> getAllFood(@PathVariable("pn") int pn,@PathVariable("ps") int pageSize,
    	@PathVariable String sortBy,@RequestBody FoodRequest foodRequest)
    {
    	return new ResponseEntity<PageFoodResponse>(this.service.viewAllFood(pn, pageSize, sortBy, foodRequest),HttpStatus.OK);
    }
    
    /**get All Active Food...*/
    @PostMapping("/active/{pn}/{ps}/{sortBy}")
    public ResponseEntity<PageFoodResponse> getAllActveFood(@PathVariable("pn") int pn,@PathVariable("ps") int pageSize,
    	@PathVariable	String sortBy,@RequestBody FoodRequest foodRequest)
    {
    	return new ResponseEntity<PageFoodResponse>(this.service.viewAllActiveFood(pn, pageSize, sortBy, foodRequest),HttpStatus.OK);
    }
    
    /**undo food*/
    @PatchMapping("/undo/{id}")
    public ResponseEntity<FoodResponse> undoFood(@PathVariable Long id)
    {
    	return new ResponseEntity<FoodResponse>(this.service.undoFood(id),HttpStatus.OK);
    }    
    
}
