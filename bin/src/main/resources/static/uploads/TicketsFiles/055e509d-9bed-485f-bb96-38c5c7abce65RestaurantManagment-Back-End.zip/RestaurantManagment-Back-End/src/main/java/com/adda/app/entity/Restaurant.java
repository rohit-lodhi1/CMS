package com.adda.app.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Restaurant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long restId;

	private String restName;

	private String restCloseTime;

	private String restOpenTime;

	private Boolean restTableStatus;

	private Boolean restPickupStatus;

	private Boolean deliveryStatus;

	private Boolean isActive;

	private Boolean waiterStatus;

	private Boolean currentStatus;

	private String address;

	private String restDescription;

	private String createdAt;

	private String lat;

	private String longg;
	@JsonIgnore
	@OneToMany(mappedBy = "restaurant")
	@JsonIgnoreProperties(value="restaurant")
	private List<Food> listOfFood;
	
	@OneToMany(mappedBy = "restaurant")
	@JsonIgnoreProperties(value="restaurant")
	@JsonIgnore
	private List<Category> listOfCategory;
	
	@OneToMany(mappedBy = "restaurant")
	@JsonIgnoreProperties(value="restaurant")
	private List<Waiter> listOfWaiter;
	
	@OneToMany(mappedBy = "rest")
	@JsonIgnore
	@JsonIgnoreProperties(value="rest")
	private List<Review> listOfReview = new ArrayList<>();
	
	@OneToMany(mappedBy = "restaurant")
	@JsonIgnoreProperties(value="restaurant")
	private List<TableSeat> listOfTables;
}
