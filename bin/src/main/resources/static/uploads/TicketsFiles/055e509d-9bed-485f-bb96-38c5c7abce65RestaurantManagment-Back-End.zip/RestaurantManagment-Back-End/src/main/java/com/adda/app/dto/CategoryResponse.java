package com.adda.app.dto;

import java.util.List;

import com.adda.app.entity.Food;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CategoryResponse {

	private Long catId;
	private String catName;
	private String catDescription;
	private Boolean isActive;
	@JsonIgnore
	private List<Food> listOfFood;
//	@JsonIgnore
	private RestaurantResponse restaurant;
}

