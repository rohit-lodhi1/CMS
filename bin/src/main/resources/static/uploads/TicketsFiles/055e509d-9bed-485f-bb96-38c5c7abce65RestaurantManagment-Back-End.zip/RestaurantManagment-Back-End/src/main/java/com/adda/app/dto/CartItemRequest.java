package com.adda.app.dto;



import com.adda.app.entity.Cart;
import com.adda.app.entity.Food;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CartItemRequest {


	private Long id;
	private Cart cart;
	private Food food;
	private int quantity;
	private Long price;
}

