package com.adda.app.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.StringMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.adda.app.dto.ReviewRequest;
import com.adda.app.dto.ReviewResponse;
import com.adda.app.dto.UserResponse;
import com.adda.app.entity.Restaurant;
import com.adda.app.entity.Review;
import com.adda.app.exception.CustomerNotFoundException;
import com.adda.app.exception.ResturantNotFoundException;
import com.adda.app.exception.ReviewNotFoundException;
import com.adda.app.helper.AppConstant;
import com.adda.app.reposatory.IRestaurantRepo;
import com.adda.app.reposatory.IReviewRepo;
import com.adda.app.service.IReviewService;
import com.adda.app.service.IUserService;

@Service
public class ReviewServiceImpl implements IReviewService {

	@Autowired
	private IReviewRepo reviewRepo;
	
	/**Autowire modelmapper ...*/
	@Autowired
	private ModelMapper moddelmapper;
	
	@Autowired
	private IRestaurantRepo restRepo;
	
	@Autowired
	private IUserService userService;
	
	@Override
	public ReviewResponse saveReview(ReviewRequest reviewReq) {
		// TODO Auto-generated method stub
		Review review = this.reviewRepo.save(this.reviewRequestToReview(reviewReq));
		return this.reviewToReviewResponse(review);
	}

	@Override
	public ReviewResponse updateReview(ReviewRequest reviewReq, Long reviewId) {
		// TODO Auto-generated method stub
		Optional<Review> findById = this.reviewRepo.findById(reviewId);
		if(findById.isPresent())
		{
		Review review = this.reviewRequestToReview(reviewReq);
		review.setReviewId(reviewId);
		this.reviewRepo.save(review);
		return this.reviewToReviewResponse(review);
		}
		throw new ReviewNotFoundException(AppConstant.REVIEW_NOT_FOUND);
	}

	@Override
	public List<ReviewResponse> getAllReview(int pn, int ps, String sortBy, ReviewRequest reviewRequest) {
		ExampleMatcher exampleMatcher = ExampleMatcher.matching()
				.withIgnoreNullValues()
				.withStringMatcher(StringMatcher.EXACT.CONTAINING)
				.withIgnoreCase()
				.withMatcher("review_id", match->match.transform(value->value.map(id->((Long)id==0)?null:id)));
		Example<Review> example = Example.of(this.reviewRequestToReview(reviewRequest),exampleMatcher);
		Pageable pageable = PageRequest.of(pn, ps,Sort.Direction.ASC,sortBy);
		Page<Review> findAllReview = this.reviewRepo.findAll(example,pageable);
		List<ReviewResponse> collect = findAllReview.getContent().stream().map(review->this.reviewToReviewResponse(review)).collect(Collectors.toList());
		Collections.shuffle(collect);
		return collect;
	}

	@Override
	public String deleteReview(Long reviewId) {
		// TODO Auto-generated method stub
		Optional<Review> findById = this.reviewRepo.findById(reviewId);
		if(findById.isEmpty())
		{
			throw new ReviewNotFoundException(AppConstant.REVIEW_NOT_FOUND);
		}
		else {
			this.reviewRepo.delete(findById.get());
			return "Review is Deleted Successfully....!!";
		}
	}

	@Override
	public List<ReviewResponse> getAllReviewOfRestaurant(int pn, int ps, String sortBy, ReviewRequest reviewRequest,Long restId) {
		// TODO Auto-generated method stub
		Optional<Restaurant> findById = this.restRepo.findById(restId);
		System.out.println(findById.get().getRestId());
		if(findById.isPresent())
		{
			System.out.println("...");
			Restaurant restaurant = findById.get();
			
			if(restaurant.getIsActive())
			{
				ExampleMatcher exampleMatcher = ExampleMatcher.matching()
						.withIgnoreNullValues()
						.withStringMatcher(StringMatcher.EXACT.CONTAINING)
						.withIgnoreCase()
						.withMatcher("review_id", match->match.transform(value->value.map(id->((Long)id==0)?null:id)));
				Example<Review> example = Example.of(this.reviewRequestToReview(reviewRequest),exampleMatcher);
				Pageable pageable = PageRequest.of(pn, ps,Sort.Direction.ASC,sortBy);
				Page<Review> findAllReview = this.reviewRepo.findAll(example,pageable);
				List<ReviewResponse> collect = findAllReview.getContent().stream().map(review->this.reviewToReviewResponse(review)).collect(Collectors.toList());
				List<ReviewResponse> response = new ArrayList<>();
				for(ReviewResponse res : collect)
				{
					if(res.getRest().getRestId() == restId)
					{
						response.add(res);
					}
				}
				return response;
			}
		}
		throw new ResturantNotFoundException(AppConstant.RESTAURANT_NOT_FOUND);
	}

	@Override
	public List<ReviewResponse> getAllReviewOfCustomer(Long customerId) {
		// TODO Auto-generated method stub
		if(this.userService.isCustomer(customerId))
		{
			UserResponse userResponse = this.userService.getById(customerId);
			List<Review> listofReview = userResponse.getListofReview();
			return listofReview.stream().map(review->this.reviewToReviewResponse(review)).collect(Collectors.toList());
		}
		throw new CustomerNotFoundException(AppConstant.CUSTOMER_NOT_FOUND);
	}
	
	
//	REVIEW TO REVIEW RESPONSE
	public ReviewResponse reviewToReviewResponse(Review review)
	{
		ReviewResponse response = this.moddelmapper.map(review, ReviewResponse.class);
		return response;
	}
	
//	REVIEW REQUEST TO REVIEW
	public Review reviewRequestToReview(ReviewRequest review)
	{
		Review response = this.moddelmapper.map(review, Review.class);
		return response;
	}
	
//	REVIEW REQUEST TO REVIEW RESPONSE
	public ReviewResponse reviewRequestToReviewResponse(ReviewRequest review)
	{
		ReviewResponse response = this.moddelmapper.map(review, ReviewResponse.class);
		return response;
	}
	
//	REVIEW REQUEST TO

}
