package com.adda.app.dto;

import com.adda.app.entity.Category;
import com.adda.app.entity.Restaurant;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class FoodRequest {

	private Long foodId;
	private String foodName;
	private Long foodPrice;
	private String foodCreatedAt;
	private String type;
	private String imageName;

	private Boolean isAvailable;
	private String foodCategoryName;
	//@ManyToOne
//	@JoinColumn(name = "restId")
    @JsonIgnore
	private Restaurant restaurant;
//	@ManyToOne
//	@JoinColumn(name = "catId")
	@JsonIgnore
	private Category category;
	public FoodRequest(String foodName, Long foodPrice, boolean isAvailable, Restaurant restaurant,
			Category category) {
		super();
		this.foodName = foodName;
		this.foodPrice = foodPrice;
		this.isAvailable = isAvailable;
		this.restaurant = restaurant;
		this.category = category;
	}
	public FoodRequest(Long foodId, String foodName, Long foodPrice,  Boolean isAvailable,
			Restaurant restaurant, Category category) {
		super();
		this.foodId = foodId;
		this.foodName = foodName;
		this.foodPrice = foodPrice;
		this.isAvailable = isAvailable;
		this.restaurant = restaurant;
		this.category = category;
	}	
	
}
