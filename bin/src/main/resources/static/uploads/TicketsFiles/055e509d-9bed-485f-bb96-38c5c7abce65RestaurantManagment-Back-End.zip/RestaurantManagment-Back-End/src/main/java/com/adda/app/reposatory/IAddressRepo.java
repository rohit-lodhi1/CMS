package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adda.app.entity.Address;

public interface IAddressRepo extends JpaRepository<Address, Long> {

}
