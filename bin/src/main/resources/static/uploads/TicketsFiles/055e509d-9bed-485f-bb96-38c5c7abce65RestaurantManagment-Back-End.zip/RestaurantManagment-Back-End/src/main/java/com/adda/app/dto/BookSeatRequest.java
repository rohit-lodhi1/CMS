package com.adda.app.dto;

import java.util.Date;

import com.adda.app.entity.Restaurant;
import com.adda.app.entity.TableSeat;
import com.adda.app.entity.User;
import com.adda.app.enums.BookingStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class BookSeatRequest {

	private Long bookedSeatId;
	private Date startTime;
	private Date endTime;
	private BookingStatus  status;

	private TableSeat table;
	
	private User user;
	
	private Restaurant restaurant;
}
