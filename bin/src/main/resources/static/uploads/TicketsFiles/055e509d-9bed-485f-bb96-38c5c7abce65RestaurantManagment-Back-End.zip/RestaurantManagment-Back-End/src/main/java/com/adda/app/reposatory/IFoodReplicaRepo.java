package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adda.app.replica.foodReplica;

public interface IFoodReplicaRepo extends JpaRepository<foodReplica, Long> {

}
