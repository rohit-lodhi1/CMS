package com.adda.app.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.dto.UserRequest;
import com.adda.app.dto.UserResponse;
import com.adda.app.entity.User;
import com.adda.app.helper.AppConstant;
import com.adda.app.jwtutil.JwtUtils;
import com.adda.app.payload.LoginResponse;
import com.adda.app.payload.LoginResquest;
import com.adda.app.service.IUserService;
@CrossOrigin("*")
@RestController
@RequestMapping("/auth")

public class AuthController {
	 @Autowired
		private AuthenticationManager authenticationmanger;
	 @Autowired
	    private JwtUtils jwtutil;
	 @Autowired
	 private IUserService service;
	 
	 //login......
	 @PostMapping("/login")
	 public ResponseEntity<LoginResponse> login(@RequestBody LoginResquest request)
	 {
		 System.out.println(request.getEmail()+"  "+request.getPassword());
		 authenticationmanger.authenticate(new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
		 String token = jwtutil.generateToken(request.getEmail());
		 return new ResponseEntity<LoginResponse>(new LoginResponse(token, AppConstant.GENERATED_BY),HttpStatus.OK);
	 }
	 	
	 //signup
	//* 1. Create User Using UserDto /
		@PostMapping("/signup")
		public ResponseEntity<UserResponse> saveUser(@RequestBody UserRequest userdto) {
				return new ResponseEntity<UserResponse>(this.service.createUser(userdto),HttpStatus.CREATED);
		}
	 
		/**get Current User...*/
		@GetMapping("/current-user")
		public ResponseEntity<User> getCurrentUser( Principal p)
		{
			System.out.println("CUrrent User APi");
			return new ResponseEntity<User>(this.service.getCurrentUser(p),HttpStatus.OK);
		}
	 
	 
}
