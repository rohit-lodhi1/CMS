package com.adda.app.service;

public interface IEmailService {
	
	public Boolean sendEmail(String subject,String message, String sendTo);
}
