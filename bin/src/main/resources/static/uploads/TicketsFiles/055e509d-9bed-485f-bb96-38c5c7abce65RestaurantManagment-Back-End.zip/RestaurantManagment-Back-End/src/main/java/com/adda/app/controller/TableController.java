package com.adda.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adda.app.dto.TableRequest;
import com.adda.app.dto.TableResponse;
import com.adda.app.service.ITableService;

@RestController
@RequestMapping("/owner/table")
public class TableController {
	
    @Autowired
	private ITableService service;
    @PostMapping("/save")
	public ResponseEntity<TableResponse> saveTable(@RequestBody TableRequest tableRequest)
	{
		return new ResponseEntity<TableResponse>(this.service.saveTable(tableRequest),HttpStatus.OK); 
	}
    @DeleteMapping("/delete/{tId}")
    public ResponseEntity<TableResponse> deleteTable(@PathVariable Long tId)
    {
    	return new ResponseEntity<TableResponse>(this.service.deleteTable(tId),HttpStatus.OK);
    }
    @PatchMapping("/undo/{id}")
    public ResponseEntity<TableResponse> undoTable(@PathVariable Long id)
    {
    	return new ResponseEntity<TableResponse>(this.service.undoTable(id),HttpStatus.OK);
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<TableResponse> updateTable(@PathVariable Long id,@RequestBody TableRequest tableRequest)
    {
    	
    	return new ResponseEntity<TableResponse>(this.service.updateTable(tableRequest, id),HttpStatus.OK);
    }
    @GetMapping("/all/{pn}/{ps}/{sortBy}")
    public ResponseEntity<List<TableResponse>> viewAllTable(@PathVariable int pn,@PathVariable int ps,@PathVariable String sortBy,@RequestBody TableRequest tableRequest)
    {
    	return new ResponseEntity<List<TableResponse>>(this.service.viewAllTable(pn, ps, sortBy, tableRequest),HttpStatus.OK);
    }
}
