package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adda.app.replica.RestaurantReplica;

public interface IRestaurantReplicaRepo extends JpaRepository<RestaurantReplica, Long> {

}
