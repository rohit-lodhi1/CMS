package com.adda.app.reposatory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.adda.app.entity.Food;

public interface IFoodRepo extends JpaRepository<Food, Long> {

	public Food findByFoodName(String foodName);
 @Query("SELECT f FROM Food f WHERE f.restaurant.restId=:rId AND f.foodName=:fName")
	public Food getFoodByRestIdAndFoodName(Long rId, String fName);
}
