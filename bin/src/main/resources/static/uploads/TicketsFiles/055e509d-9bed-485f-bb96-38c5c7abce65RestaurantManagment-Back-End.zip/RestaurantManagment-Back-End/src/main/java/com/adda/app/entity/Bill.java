package com.adda.app.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Bill {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String billNo;
	private LocalDateTime addAt = LocalDateTime.now();
	@OneToOne
	@JoinColumn(name="orderIdfk")
	private Orders order;
	@OneToOne
	@JoinColumn(name="userIdfk")
	private User user;
	
	
}
