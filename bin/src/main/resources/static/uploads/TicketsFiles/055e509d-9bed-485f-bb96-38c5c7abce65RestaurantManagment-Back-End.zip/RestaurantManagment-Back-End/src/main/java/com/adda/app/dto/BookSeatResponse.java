package com.adda.app.dto;

import java.util.Date;

import com.adda.app.enums.BookingStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class BookSeatResponse {
	private Long bookedSeatId;
	private Date startTime;
	private Date endTime;
	private BookingStatus  status;
   // @JsonIgnore
	private TableResponse table;
	private UserResponse user;
//    @JsonIgnore
	private RestaurantResponse restaurant;
}
