package com.adda.app.serviceimpl;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adda.app.dto.CartItemResponse;
import com.adda.app.dto.CartRequest;
import com.adda.app.dto.CartResponse;
import com.adda.app.entity.Cart;
import com.adda.app.entity.CartItem;
import com.adda.app.entity.User;
import com.adda.app.exception.ResourceNotFoundException;
import com.adda.app.helper.AppConstant;
import com.adda.app.reposatory.ICartItemRepo;
import com.adda.app.reposatory.ICartRepo;
import com.adda.app.service.ICartService;
import com.adda.app.service.IUserService;

@Service
public class CartServiceImpl implements ICartService {
	@Autowired
	private ICartRepo repo;
	@Autowired
	private IUserService service;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private ICartItemRepo itemRepo;

	@Override
	public CartResponse createCart(Principal p) {
		// TODO Auto-generated method stub
		User u = service.getCurrentUser(p);
		Cart c = new Cart();

		Cart c1 = repo.findByUser(u);
		if (c1 != null) {
			throw new ResourceNotFoundException(AppConstant.CART_EXIST);
		} else {
			c.setUser(u);
			return this.CartToCartResponse(this.repo.save(c));
		}
	}

	@Override
	public List<CartItemResponse> checkCart(Principal p) {
		// TODO Auto-generated method stub
		User u = service.getCurrentUser(p);
		Cart c = repo.findByUser(u);
		List<CartItem> cartItem = itemRepo.findByCartId(c.getId());
		List<CartItemResponse> cartItemResponse = new ArrayList<>();
		if (cartItem.isEmpty()) {
			throw new ResourceNotFoundException(AppConstant.CART_ISEMPTY);
		} else {
			for (CartItem item : cartItem) {
				cartItemResponse.add(this.CartItemToCartItemResponse(item));
			}
			return cartItemResponse;
		}
	}

	/** Convert Cart To CartResponse.... */
	public CartResponse CartToCartResponse(Cart cart) {
		return this.modelMapper.map(cart, CartResponse.class);
	}

	/** Convert Cart To CartResponse.... */
	public Cart CartReQuestToCart(CartRequest cartRequest) {
		return this.modelMapper.map(cartRequest, Cart.class);
	}

	/** Convert CartItem To CartItemResponse...!! */

	public CartItemResponse CartItemToCartItemResponse(CartItem item) {
		return this.modelMapper.map(item, CartItemResponse.class);
	}

}
