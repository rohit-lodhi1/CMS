package com.adda.app.serviceimpl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adda.app.dto.BookSeatRequest;
import com.adda.app.dto.BookSeatResponse;
import com.adda.app.entity.BookedSeat;
import com.adda.app.enums.BookingStatus;
import com.adda.app.reposatory.IBookedSeatRepo;
import com.adda.app.service.IBookSeatService;
@Service
public class BookSeatServiceImpl  implements IBookSeatService{

	@Autowired
	private IBookedSeatRepo repo;
	@Autowired
	private ModelMapper mapper;
//	@Autowired
//	private INotificationService notificationService;

	@Override
	public BookSeatResponse bookTable(BookSeatRequest bookSeatRequest) {
		
		List<BookedSeat> overlappingBookings = repo.findOverlappingBookings(bookSeatRequest.getTable().getTableNo(),bookSeatRequest.getStartTime(),bookSeatRequest.getEndTime());
		if(!overlappingBookings.isEmpty()) 
		{
			bookSeatRequest.setStatus(BookingStatus.WAITING);
		}
		else {
			bookSeatRequest.setStatus(BookingStatus.CONFIRMED);
		}
		BookedSeat bookedSeat = this.bookSeatRequestToBookSeat(bookSeatRequest);
		BookedSeat bookedSeat2= this.repo.save(bookedSeat);
		//notificationService.notifyAdminAndOwner("New table booking received! Table: "+bookedSeat.getTable().getTableNo());
		return this.bookSeatToBookSeatResponse(bookedSeat2);
	}
	


	/**bookSeatRequest Convert to bookSeat */
	private BookedSeat bookSeatRequestToBookSeat(BookSeatRequest bookSeatRequest) 
	{
		return this.mapper.map(bookSeatRequest, BookedSeat.class);
	}
	/**bookSeat Convert to bookSeatResponse */
	private BookSeatResponse bookSeatToBookSeatResponse(BookedSeat bookedSeat) 
	{
		return this.mapper.map(bookedSeat, BookSeatResponse.class);
	}
}
