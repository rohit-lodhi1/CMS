package com.api.app;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.api.app.repository.UserRepository;

@SpringBootTest
class BlogAppApisApplicationTests {

	@Autowired
	private UserRepository userRepository;
	
	@Test
	void contextLoads() {
	}

	@Test
	public void repoTest() {
		String ClassName = this.userRepository.getClass().getName();
		String packName = this.userRepository.getClass().getPackageName();
		System.out.println(ClassName);
		System.out.println(packName);
		
	}
	
}
