package com.api.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.api.app.entity.Category;

public interface CategoryRepository extends JpaRepository<Category,Integer > {

}
