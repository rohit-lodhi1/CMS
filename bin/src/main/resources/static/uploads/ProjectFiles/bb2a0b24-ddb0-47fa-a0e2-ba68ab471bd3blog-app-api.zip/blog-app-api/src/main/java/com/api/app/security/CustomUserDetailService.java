package com.api.app.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.api.app.entity.User;
import com.api.app.exception.ResourceNotFoundException;
import com.api.app.repository.UserRepository;

@Service
public class CustomUserDetailService implements UserDetailsService {

	
	@Autowired
	private UserRepository userRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		
	// loading user from database by userName
		User user = this.userRepo.findByEmail(username).orElseThrow(()->new ResourceNotFoundException("username", "email :"+username,0));
		
		return user;
	}

}
